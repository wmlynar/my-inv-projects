# Fleet Manager 2.0 — Strategia testów (v0.4)

Wymaganie: piramida testów + możliwość uruchamiania równolegle.

## 1. Piramida testów (MUST)
1) **Unit tests** (najwięcej, najszybsze)
   - contracts validation
   - Map Compiler: parser + geometry utils
   - Core: reducer/event-sourcing, task runner, lock manager
   - Gateway: parser framing, idempotency, provider switch

2) **Integration tests**
   - Core ↔ Gateway (HTTP) z mock robot
   - Gateway ↔ robokit-sim (TCP) dla goTarget/forkHeight/push
   - Core ↔ Algorithm Service (HTTP) (mock albo real algo)

3) **E2E tests**
   - uruchom pełny stack: core + gateway + algo + robokit-sim + ui headless
   - odpal scenariusze z `18_scenariusze_e2e.md`

## 2. Równoległość testów (MUST)
- Testy MUST dać się uruchamiać równolegle (np. w CI).
- Zasady:
  - każdy test używa osobnego `dataDir` (temp dir),
  - porty są losowane lub przydzielane per suite,
  - brak globalnych singletonów w procesie testów (albo izolacja przez worker).

## 3. Golden tests (SHOULD)
- Map Compiler: `graph.json` jako golden output.
- Gateway: golden TCP traces.
- Core: replay golden eventlog+snapshot i porównanie state.

## 4. Testy odporności (SHOULD)
- symulacja przerw w sieci (drop TCP, timeouts)
- symulacja opóźnień i partial frames
- testy idempotencji (powtarzanie dispatch komend)

## 5. Coverage i definicja „done” (MUST)
MVP jest „done”, jeśli:
- każdy endpoint ma testy pozytywne i negatywne,
- każdy kluczowy reasonCode jest generowany w kontrolowanym teście,
- każdy scenariusz e2e przechodzi deterministycznie.
