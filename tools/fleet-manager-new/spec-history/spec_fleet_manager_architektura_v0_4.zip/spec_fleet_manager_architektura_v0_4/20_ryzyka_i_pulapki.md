# Fleet Manager 2.0 — Ryzyka i pułapki (v0.4)

## 1. Największe ryzyko: integracja RoboCore/Robokit (warianty protokołu)
Objawy:
- różne implementacje `reserved/jsonSize`,
- payloady różnią się wersją robota,
- push może działać inaczej.

Mitigacje (MUST/SHOULD):
- Gateway MUST mieć parser odporny na warianty i partial frames.
- Proxy/Recorder SHOULD zbierać capture z realnego systemu.
- Golden traces MUST być częścią CI (integracja).

## 2. Ryzyko: brak spójności mapy między sceną a robotem
Objawy:
- `goTarget(id)` nie działa albo jedzie inaczej.

Mitigacje:
- UI MUST pokazywać `robot.current_map` (jeśli dostępne).
- Procedury operacyjne: aktywna scena = mapa robota.
- Future: auto load map (poza MVP).

## 3. Ryzyko: event storm / duże payloady
Mitigacje:
- SSE filters, thin state view, gzip (SHOULD).
- Snapshot co N ms, a delty tylko zmian.

## 4. Ryzyko: niejednoznaczność lifecycle komend i tasków
Mitigacje:
- Jawne state machines (już są w `07_*`).
- Testy na edge-case’y (retry, cancel, timeout).

## 5. Ryzyko: przełączanie providerów w trakcie ruchu
Mitigacje:
- Safe-switch: stop best-effort, hold, potem switch.
- UI warnings + logs.

## 6. Ryzyko: „AI implementuje inaczej niż intencja”
Mitigacje:
- kontrakty + przykłady JSON5 (czytelne),
- jasne MUST/SHOULD,
- golden tests,
- małe moduły z wąskimi interfejsami.

## 7. Ryzyko: ukryte zależności między modułami
Mitigacje:
- kontrakty w osobnym pakiecie,
- zakaz importów cross-boundary,
- mockowanie integracji w testach.
