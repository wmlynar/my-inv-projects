# Fleet Manager 2.0 — Scenariusze end-to-end (v0.4)

Scenariusze mają dwie funkcje:
- są „żywą specyfikacją”,
- są testami E2E/regresji.

## Scenariusz 1: Start systemu bez UI (headless)
1) Uruchom Core, Gateway, Algo.
2) Import sceny (CLI lub API).
3) Activate scenę.
4) Core emituje `stateSnapshot`, `sceneActivated`.
5) Brak UI — system działa i publikuje SSE.

Oczekiwane:
- `/health` ok
- `/state` zawiera activeSceneId
- event log + snapshot na dysku

## Scenariusz 2: Dwa UI, jedno przejmuje kontrolę (seize control)
1) UI-A i UI-B łączą się do SSE.
2) UI-A robi `seize` (lease).
3) UI-B próbuje utworzyć task → 409 `CONTROL_LEASE_REQUIRED`.
4) UI-A robi `force seize` z UI-B (jeśli ustawione) → UI-B widzi wywłaszczenie.

## Scenariusz 3: goTarget (rolling target) na robokit-sim
1) Gateway przełącza RB-01 na `robokitSim`.
2) Core wysyła manual `goTarget(LM2)`.
3) Gateway wysyła TCP 3051 `{id:"LM2"}`.
4) Robot push/status pokazuje target i ruch.
5) Core widzi `arrived` → `commandCompleted`.

## Scenariusz 4: forkHeight jako ActionPoint
1) Scena ma `actionPoints.json5` dla `AP_PICK_01` (forkHeight 1.2m).
2) Task runner doprowadza robota do `AP_PICK_01` (goTarget).
3) Po arrival Core wysyła `forkHeight(height=1.2)` (6040).
4) Core czeka aż fork status osiągnie wysokość.
5) Eventy: `commandUpdated` + `taskUpdated`.

## Scenariusz 5: Przerwa sieci do robota
1) Robot w trakcie jazdy.
2) Zrywamy TCP.
3) Gateway przechodzi w offline i raportuje.
4) Core holduje dispatch + emituje `systemWarning(DEPENDENCY_OFFLINE)`.
5) Po reconnect: kontynuacja.

## Scenariusz 6: Scene activation w trakcie ruchu
1) Robot jedzie.
2) UI robi activate nowej sceny.
3) Core wysyła best-effort stop, anuluje komendy i taski, resetuje locki.
4) Po aktywacji: stan czysty, UI widzi nową scenę.

## Scenariusz 7: Hot switch internalSim ↔ robocore (pojedynczy robot)
1) System startuje na internalSim.
2) W trakcie symulacji przełączamy RB-01 na robocore.
3) Core wykonuje safe-switch.
4) Robot kontynuuje wg nowych komend.
