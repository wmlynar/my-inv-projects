# Fleet Manager 2.0 — API Fleet Gateway (wewnętrzne) (v0.4)

Base URL: `http://<gateway-host>:<port>/gateway/v1`

## 1. Zasady ogólne
- Gateway obsługuje providerów per-robot.
- Gateway nie jest źródłem prawdy domenowej (source of truth = Core).
- Gateway MUST być idempotentny dla komend z `commandId`.
- Gateway MUST implementować retry/reconnect/circuit breaker na TCP do robota.
- Gateway MUST logować integracyjne błędy do `captureDir` (gdy debug enabled).

## 2. Health
### GET /health
```json5
{ status: "ok", tsMs: 1736160000000 }
```

## 3. Robots
### GET /robots
Response:
```json5
{
  robots: [
    {
      robotId: "RB-01",
      provider: { kind: "robocore", status: "online", lastSeenTsMs: 1736160000123 },
      raw: { /* opcjonalny raw status z robota (zewn.) */ },
      normalized: { /* RobotRuntimeState subset */ }
    }
  ]
}
```

### GET /robots/{robotId}/status
Response:
```json5
{ robotId: "RB-01", normalized: { /* RobotRuntimeState subset */ } }
```

## 4. Commands (Core→Gateway)
### POST /robots/{robotId}/commands
Request:
```json5
{
  commandId: "cmd_01JH...",
  robotId: "RB-01",
  type: "goTarget", // MUST
  payload: {
    targetRef: { nodeId: "LM2" }, // goTarget

    // forkHeight
    toHeightM: 1.20,
  },

  // korelacja
  request: { clientId: "ui-01", requestId: "req_01..." },
}
```

Response 200:
```json5
{
  commandId: "cmd_01JH...",
  status: "acknowledged",       // lub dispatched/failed zależnie od typu
  statusReasonCode: "NONE",
  providerCommand: { /* debug: mapping do robota */ },
}
```

Errors:
- 404 jeśli `robotId` nieznany
- 503 jeśli provider offline
- 400 jeśli payload niepoprawny

**Idempotencja:**
- Powtórzony request z tym samym `commandId` MUST zwrócić ten sam rezultat (lub semantycznie równoważny).

## 5. Provider switch
### POST /robots/{robotId}/provider-switch
Request:
```json5
{
  robotId: "RB-01",
  targetProvider: "internalSim", // internalSim | robokitSim | robocore
  reason: "test",
}
```
Response:
```json5
{ ok: true, robotId: "RB-01", provider: { kind: "internalSim", status: "online" } }
```

Gateway MUST:
- zamknąć połączenia TCP starego providera,
- podnieść nowy provider,
- nie gubić informacji o ostatnim statusie (może być stale), ale MUST to oznaczyć.

## 6. Debug endpoints (MAY)
- `GET /robots/{robotId}/capture/latest`
- `GET /robots/{robotId}/raw-status`
- `POST /robots/{robotId}/tcp/reconnect`

## 7. Kontrakt “provider layer” (wewnętrzny)
Każdy provider w gateway MUST implementować:
- `connect()` / `disconnect()`
- `getNormalizedStatus()`
- `sendCommand(command)`
- `configurePush()` (jeśli wspiera)

Szczegóły protokołu TCP w `10_protokol_robocore_robokit.md`.
