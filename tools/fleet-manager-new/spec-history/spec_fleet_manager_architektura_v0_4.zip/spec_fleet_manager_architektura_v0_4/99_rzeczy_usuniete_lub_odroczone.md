# Fleet Manager 2.0 — Rzeczy usunięte / odroczone (v0.4)

Ta sekcja istnieje, żeby nic „nie zniknęło”. Rzeczy nie pasujące do MVP albo wymagające RE są tu, zamiast ginąć.

## 1. Usunięte / zmienione względem wcześniejszych wersji
- gRPC: w v0.4 przyjęto zasadę „HTTP wszędzie” dla komunikacji wewnętrznej (Core/Gateway/Algo/UI).
- Rolling target jako (x,y): zastąpione rolling target jako NodeRef (LM/AP) i mapowanie na RoboCore `goTarget` (3051).
- Capability negotiation: odroczone (Twoje wymaganie: „implementujemy wszystko na tym etapie”).

## 2. Poza MVP (odroczone)
- Security (authN/authZ, TLS, RBAC).
- Multi-tenant.
- Multi-instance Core / HA (wymaga ADR i wspólnego storage).
- Automatyczne ładowanie mapy do robota (map upload/switch).
- Zaawansowane avoidance w miejscach `corridorWidthM > 0` (lokalne planowanie + constraints).
- Designated path navigation (3066) jako główny tryb — na razie opcjonalnie.
- Zaawansowane planowanie i deadlock recovery (MAPF, priorytety) — opis w spec algorytmu.

## 3. Elementy wymagające doprecyzowania po reverse engineering
- Pełna tabela payloadów RoboCore/Robokit (nie wszystkie są w tej spec).
- Dokładne error codes robota i mapowanie na ReasonCodes FM.
- Semantyka `robot_control_reloc_req` (2002) w konkretnych robotach.
