# Fleet Manager 2.0 — Architektura wysokopoziomowa (v0.4)

## 1. Cel systemu
Fleet Manager steruje flotą autonomicznych wózków widłowych w obrębie jednej aktywnej sceny,
minimalizując ryzyko kolizji i przestojów, przy założeniu, że robot ma własny lokalny planner
i może lokalnie omijać przeszkody (docelowo).

W MVP Fleet Manager:
- MUST działać bez frontendu (headless),
- MUST wspierać wiele frontendów równolegle (obserwacja), z wyłącznością sterowania (lease/seize),
- MUST wspierać symulację wielu robotów (wewnętrzną),
- MUST pozwalać przełączać pojedynczego robota między providerami (internal sim ↔ robokit-sim ↔ real robot),
- MUST wspierać dynamiczną zmianę sceny (import + activation),
- MUST zapewniać pełny audyt/replay: event log + snapshoty na dysk.

## 2. Zasada nadrzędna: domena oddzielona od integracji
- **Fleet Core** = domena + deterministyczna logika + publiczne API + persystencja.
- **Integracje** (roboty, Roboshop, proxy) są poza domeną i mają cienkie adaptery.

Konsekwencje:
- Core MUST działać bez robotów (np. tylko symulacja) i bez UI.
- Core MUST być testowalny z mockami gateway/algorytmu.
- Gateway MUST być wymienialny bez zmiany logiki domenowej.

## 3. Kontenery / procesy (MVP)
Poniżej logiczne komponenty; MVP dopuszcza monorepo, ale granice muszą być „twarde” kontraktami.

1) **fleet-core** (HTTP `/api/v1`)
   - stan sceny, robots, worksites, streams, tasks, locks
   - tick loop
   - event sourcing (event log + snapshot)
   - integracja z algorytmem (HTTP do algorithm-service)

2) **algorithm-service** (HTTP `/algo/v1`)
   - czysta funkcja decyzyjna na snapshotach
   - wiele implementacji algorytmu (konfigurowalne)

3) **fleet-gateway** (HTTP `/gateway/v1`)
   - integracja robotów (RoboCore/Robokit TCP)
   - provider switching
   - normalizacja statusów
   - retry/reconnect/circuit breaker na TCP

4) **ui-frontend** (WWW)
   - wyświetlanie mapy, robotów, worksites, streams, tasków
   - interakcje użytkownika (ale bez logiki domenowej)

5) **roboshop-bridge** (opcjonalnie osobny proces)
   - import mapy/sceny z Roboshop do Fleet Core (HTTP)

6) **map-compiler** (CLI/tool)
   - deterministyczna kompilacja `.smap` → `graph.json` (SceneGraph)

7) **proxy-recorder** (dev tool)
   - podsłuch TCP/HTTP, zapisy PCAP/JSONL, wsparcie reverse engineering

## 4. Komunikacja (MUST: HTTP wewnątrz systemu)
- UI ↔ Core: HTTP + SSE (jednokierunkowy stream zdarzeń)
- Core ↔ Gateway: HTTP (komendy + odczyt stanu)
- Core ↔ Algorithm: HTTP (snapshot → decyzja)
- Gateway ↔ Robot: TCP (RoboCore/Robokit framing) — to jest wyjątek (zewnętrzny protokół)

## 5. Model spójności i skalowania (MVP)
- Core jest **single-writer** (jedna instancja) w MVP.
- Wszystkie modyfikacje stanu Core MUST przechodzić przez event log.
- Event `cursor` jest monotoniczny w ramach instancji.

Future-proof (nie w MVP, ale bez blokady):
- HA/klaster wymaga wspólnego storage i leader election (ADR).
- Snapshoty MUSZĄ mieć `schemaVersion` i możliwość migracji (tool MAY).

## 6. Najważniejsze „twarde” wymagania jakościowe
- System MUST być odporny na przerwy w sieci: retry/timeout/backoff, ale bez „pętli śmierci”.
- System MUST być deterministyczny w replay (to krytyczne dla debug i dla pracy z AI).
- Interfejsy MUST być czytelne dla ludzi: przykłady JSON5 + komentarze.

## 7. Minimalny MUST-checklist (bezpieczeństwo operacyjne)
(to jest krótka lista „co musi się zgadzać”, zanim robot pojedzie)

Core MUST:
- mieć aktywną scenę,
- mieć aktualny stan robota (nie starszy niż `statusAgeMaxMs`),
- mieć ważny lease (jeśli komenda pochodzi od UI),
- mieć brak konfliktu locków dla segmentu,
- zapisać `CommandRecord` do event log przed dispatch.

Gateway MUST:
- mieć połączenie TCP do robota (albo jednoznaczny status offline),
- parsować ramki w sposób odporny na partial frames,
- nie wysyłać komend, jeśli robot jest w emergency (MUST fail-safe),
- logować raw frames do capture (gdy debug enabled).

Szczegóły: `07_semantyka_runtime_i_maszyny_stanow.md`, `16_obserwowalnosc_i_replay.md`.
