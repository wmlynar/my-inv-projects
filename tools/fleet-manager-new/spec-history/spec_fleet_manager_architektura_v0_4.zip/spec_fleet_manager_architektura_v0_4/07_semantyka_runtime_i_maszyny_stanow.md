# Fleet Manager 2.0 — Semantyka runtime i maszyny stanów (v0.4)

Ten plik jest „kanonem zachowania” systemu. Tu są reguły, które minimalizują niejednoznaczność implementacji.

## 1. Single-writer Core (ADR, MVP)
- W MVP Core jest pojedynczą instancją (single-writer).
- `cursor` jest monotoniczny w obrębie instancji.
- HA jest poza MVP, ale kontrakty MUST mieć `schemaVersion`, a logi/snapshoty muszą dać się migrować.

## 2. Control Lease (seize control)
Cel: wiele UI może patrzeć, ale tylko jedno może sterować.

### 2.1 Kontrakt ControlLease
```json5
{
  leaseId: "lease_01JH...",
  owner: { clientId: "ui-01", displayName: "UI Traffic Lab" },
  acquiredTsMs: 1736160000000,
  expiresTsMs: 1736160015000,
  lastRenewTsMs: 1736160009000,
  status: "held", // held | expired | released
  statusReasonCode: "NONE",
}
```

### 2.2 Reguły (MUST)
- Jeśli UI chce sterować, MUST wykonać `seize`.
- `seize` MAY być `force=true` jeśli `allowForceSeize=true`.
- Jeśli `force=true`, poprzedni owner zostaje wywłaszczony:
  - Core MUST emitować event `controlLeaseSeized` (lub `systemWarning` z causeCode `CONTROL_LEASE_SEIZED`).
- Wszystkie endpointy modyfikujące stan (create task, manual command, activate scene, provider switch)
  MUST wymagać ważnego lease. Brak → `409 conflict` + `causeCode=CONTROL_LEASE_REQUIRED`.

### 2.3 State machine (ASCII)
```text
FREE
  | seize
  v
HELD -- renew --> HELD
  | release
  v
RELEASED
  | (implicit)
  v
FREE

HELD -- ttl expires --> EXPIRED --> FREE
HELD -- force seize --> HELD(new owner)
```

## 3. Scene Activation (przełączanie sceny)

### 3.1 Reguły nadrzędne (MUST)
- Core MUST mieć w danym momencie co najwyżej jedną scenę aktywną.
- Aktywacja sceny MUST być atomowa z perspektywy klientów (albo jest w pełni aktywna, albo nie).
- Podczas aktywacji Core MUST przejść w tryb `activating` i:
  - MUST zablokować przyjmowanie nowych komend/tasków (409 `SCENE_NOT_ACTIVE`),
  - MUST wstrzymać dispatch do gateway (hold robots).

### 3.2 Procedura aktywacji (MUST)
1) Validate scene package (manifest + graph + config).
2) Build derived runtime state:
   - index nodes/edges,
   - reset locks/reservations,
   - init tasks/streams state.
3) Emit event `sceneActivated` + write snapshot.
4) Unfreeze dispatch.

Jeśli fail:
- Emit `sceneActivationFailed` (z causeCode).
- Core MUST pozostać na poprzedniej scenie (jeśli była) lub w stanie `noActiveScene`.

### 3.3 Co się dzieje z runtime przy zmianie sceny (MUST)
- Wszystkie `locks` i `reservations` są resetowane.
- Wszystkie `tasks` w toku są `canceled` z `statusReasonCode=SCENE_NOT_ACTIVE` (lub przeniesione do `failed`).
- Wszystkie `commands` w toku są `canceled` (Core zapisuje to w event log) i Core wysyła `stop` do gateway (best effort).
- Provider robota **nie zmienia się automatycznie** (SHOULD), ale robot może mieć niepasującą mapę:
  - to jest ryzyko operacyjne i MUST być wyraźnie widoczne w UI (warning).
  - w przyszłości: auto load map (poza MVP).

## 4. Command lifecycle (CommandRecord) — state machine

### 4.1 Stany
- `created` — zapisane w event log, jeszcze nie wysłane do gateway.
- `dispatched` — wysłane do gateway (HTTP ok).
- `acknowledged` — gateway potwierdził przyjęcie / robot zwrócił ACK (w zależności od komendy).
- `completed` — komenda zakończona sukcesem (osiągnięto target / wykonano akcję).
- `failed` — błąd wykonania (timeout, robot error, reject).
- `canceled` — anulowana przez Core (np. zmiana sceny, seize, manual stop).

### 4.2 State machine (ASCII)
```text
created -> dispatched -> acknowledged -> completed
    |          |             |
    |          |             -> failed
    |          -> failed
    -> canceled
dispatched/acknowledged -> canceled
```

### 4.3 Reguły idempotencji (MUST)
- Core MUST nadać `commandId` i użyć go jako idempotency key w Core→Gateway.
- Core MUST zapisać event `commandCreated` zanim spróbuje dispatch.
- Gateway MUST traktować ponowny dispatch z tym samym `commandId` jako idempotentny (zwracać ten sam rezultat).

### 4.4 Retry (MUST)
- Core MUST NOT retry „w kółko” komend do robota.
  Core retry dotyczy tylko HTTP do gateway i tylko w granicach `gateway.retry.maxAttempts`.
- Gateway jest odpowiedzialny za retry/reconnect TCP i MUST implementować circuit breaker.

## 5. Task lifecycle (Task) — state machine (MVP)

```text
created -> assigned -> running -> completed
  |          |          |
  |          |          -> failed
  |          -> canceled
  -> canceled
running -> canceled
```

- Task Runner w Core MUST wykonywać kroki sekwencyjnie.
- Dla kroków `moveTo` Core dispatchuje `goTarget` (rolling target) aż do `arrived`.
- Dla kroków `forkHeight` Core wysyła `forkHeight` (6040) i czeka na osiągnięcie `targetHeightM` (z tolerancją).

## 6. Provider switching (hot switch) — reguły (MUST)
- Zmiana providera jest operacją „bezpieczną”: Core MUST najpierw wymusić `stop` (best effort),
  a dopiero potem przełączyć providera w gateway.
- Core MUST emit `robotProviderSwitched` i zapisać snapshot.
- Gateway MUST umieć przełączyć providera per-robot bez restartu procesu.

Szczegóły w `11_symulacja_i_hot_switch_providerow.md`.

## 7. SSE i cursor semantics (MUST)
- SSE niesie wyłącznie `EventEnvelope`.
- `id:` w SSE MUST równać się `EventEnvelope.cursor`.
- Snapshot jest zdarzeniem `type="stateSnapshot"` i też ma `cursor`.
- Precedencja: jeśli klient poda `fromCursor`, Core MUST zignorować `Last-Event-ID`.
- Jeśli `fromCursor` jest poza retencją:
  - Core MUST wysłać `stateSnapshot` z `payload.requiresResync=true` i rozpocząć stream od tej migawki.
