# Fleet Manager 2.0 — Map Compiler (v0.4)

Map Compiler to narzędzie (CLI/biblioteka), które tworzy kanoniczny `SceneGraph` z mapy `.smap`.

## 1. Wejścia / wyjścia (MUST)
Input:
- `.smap` (źródło geometrii)
- opcjonalne dodatkowe pliki (np. nazwy warstw, metadane)

Output:
- `map/graph.json` zgodny z `04_kontrakty_scena_i_mapa.md`.

## 2. Wymagania deterministyczności (MUST)
- Dla tego samego `.smap` wynik `graph.json` MUST być identyczny (bitwise), chyba że zmieniono wersję kompilatora.
- Kompilator MUST mieć `compilerVersion` w `meta` (SHOULD), np. `meta.compilerVersion = "map-compiler-0.4.0"`.

## 3. Geometria (MUST)
- Kompilator MUST zachować geometrię krawędzi, w tym `DegenerateBezier` (control points).
- Kompilator MUST wyliczać:
  - `lengthM` (arc length, deterministycznie),
  - `direction` (z props mapy),
  - `corridorWidthM` (z props width; jeśli brak to 0),
  - inne derived pola potrzebne algorytmowi (np. forbiddenRotAngleRad), jeśli istnieją w źródle.

## 4. Konwersja jednostek (MUST)
- Jeśli `.smap` używa innej skali: kompilator MUST przeliczyć do metrów (`xM`, `yM`).
- `meta.resolutionM` MUST odzwierciedlać końcową rozdzielczość.

## 5. Walidacje (MUST)
Kompilator MUST wykrywać i raportować:
- brakujące węzły referencjonowane przez krawędzie,
- duplikaty id,
- NaN/Infinity,
- puste grafy.

Raport walidacji SHOULD zawierać `causeCode` oraz listę błędów.

## 6. Opcjonalne próbkowanie geometrii (SHOULD)
Kompilator SHOULD dodawać `geometrySamples` na krawędziach (patrz `04_*`),
aby:
- uprościć symulację,
- uprościć wizualizację,
- uniknąć duplikowania implementacji Béziera w wielu modułach.

## 7. Testy Map Compiler (MUST)
- testy jednostkowe dla parsera `.smap`,
- testy deterministyczności,
- testy kompatybilności z `graph.json` (np. z dołączonym `graph.json` jako golden).

Szczegóły: `17_strategia_testow.md`.
