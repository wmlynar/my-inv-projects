# Fleet Manager 2.0 — MVP (dokładna definicja) (v0.4)

MVP ma być podstawą do implementacji pierwszej wersji algorytmu i uruchomienia na symulatorze oraz na robocie.

## 1. MUST w MVP

### 1.1 Core
- Import sceny (katalog lub zip) + walidacja.
- Activate sceny (procedura atomowa).
- `/state` snapshot + `/events` SSE.
- ControlLease (seize/renew/release).
- Event log + snapshoty **na dysk**.
- Manual commands: `stop`, `goTarget`.
- Task: `pickDrop` z minimalnym Task Runner (sekwencja kroków).
- Integracja z Algorithm Service (HTTP): `POST /algo/v1/decide` (może być stub algo w MVP, ale interfejs musi istnieć).

### 1.2 Gateway
- Provider: `robokitSim` + `robocore` (ten sam protokół TCP) + `internalSim`.
- Obsługa RoboCore framing.
- Komendy TCP: 3051 goTarget, 2000 stop, 6040 forkHeight, 6041 forkStop.
- Status: minimum `loc` (1004) i push (9300/19301) albo polling.
- Idempotencja dla `commandId`.
- Hot-switch providera per robot.

### 1.3 Algorithm Service
- `/health`
- `/decide`
- deterministyczny stub (np. zawsze hold) albo minimalna logika.

### 1.4 UI
- read-only dashboard: mapa + roboty + tasks + worksites.
- kontrola: seize/release + manual stop + manual goTarget.
- (opcjonalnie) widok logów / zdarzeń.

### 1.5 Map Compiler
- `.smap` → `graph.json` (nodes, edges, DegenerateBezier, propsCompiled.lengthM).
- deterministyczność + walidacje.

## 2. SHOULD w MVP (silnie zalecane)
- SSE filter `types=`.
- `/state?view=uiMinimal`.
- Gateway capture w debug.
- Golden trace pipeline.

## 3. Poza MVP (explicit)
- Security (authN/authZ/TLS/RBAC)
- Multi-instance Core / HA
- Automatyczne ładowanie mapy do robota
- Pełna obsługa designated path / multistation / advanced avoidance
- Rozbudowane UI (edycja sceny w UI)

## 4. Kryteria akceptacji MVP (MUST)
- Wszystkie scenariusze z `18_scenariusze_e2e.md` przechodzą na robokit-sim.
- Event log + snapshot pozwalają odtworzyć stan po awarii.
- Przerwy w komunikacji nie powodują „pętli komend” i nie gubią audytu.
