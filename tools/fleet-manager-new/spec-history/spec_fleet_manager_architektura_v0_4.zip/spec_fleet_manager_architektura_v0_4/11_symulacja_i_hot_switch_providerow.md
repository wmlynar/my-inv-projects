# Fleet Manager 2.0 — Symulacja i hot-switch providerów (v0.4)

## 1. Provider model (MUST)
Gateway obsługuje provider per-robot:
- `internalSim` — deterministyczna symulacja 2D (wiele robotów, kolizje)
- `robokitSim` — zewnętrzny symulator po protokole RoboCore/Robokit TCP
- `robocore` — prawdziwy robot po protokole RoboCore/Robokit TCP

Core widzi tylko `provider.kind` i `RobotRuntimeState` (znormalizowany).

## 2. InternalSim — wymagania (MUST)
- Symulator MUST obsługiwać wiele robotów w jednej scenie.
- Symulator MUST uwzględniać kolizje robot-robot na poziomie „footprint + safetyMargin”.
- Symulator SHOULD korzystać z geometrii mapy (DegenerateBezier → polilinia) dla ruchu po trasie.
- Symulator MUST mieć tryb deterministyczny (seed) i generować te same eventy przy tym samym wejściu.

Minimalny model ruchu (MVP):
- robot porusza się po kolejnych węzłach (LM/AP) z prędkością `maxVxMps`,
- skręty są dyskretne (ustawienie angle na końcu krawędzi),
- kolizja wykrywana jako przecięcie footprintów; reakcja: zatrzymanie + `blocked`.

## 3. Hot switch (Core→Gateway) — procedura (MUST)
Przełączanie pojedynczego robota w trakcie symulacji jest dozwolone.

### 3.1 Bezpieczna sekwencja
1) Core emituje `commandCreated(stop)` i dispatchuje do Gateway (best effort).
2) Core wywołuje `POST /gateway/v1/robots/{robotId}/provider-switch`.
3) Core emituje `robotProviderSwitched` i zapisuje snapshot.
4) Core wznawia Task Runner / rolling target dla tego robota dopiero, gdy `provider.status=online`.

### 3.2 Co jeśli stop się nie uda?
- To jest best-effort.
- Core MUST oznaczyć `statusReasonCode=PROVIDER_SWITCHING` i wyświetlić warning w UI.
- W przyszłości: hard interlock (poza MVP).

## 4. Przełączenie robota na „robokitSim” (test bez prawdziwego robota)
Cel: uruchomić ten sam algorytm i te same kontrakty, a zamiast internal sim sterować robokit-sim.

Wymagania:
- Gateway MUST używać tego samego kodu protokołu TCP dla `robokitSim` i `robocore`.
- Core nie powinien wiedzieć, czy robot jest prawdziwy czy symulowany.

## 5. Przełączenie na prawdziwego robota (robocore)
- W MVP dopuszczamy ręczne zapewnienie, że mapa robota odpowiada aktywnej scenie.
- Core/Gateway MUST udostępniać status: `currentMap`/`mapName` jeśli dostępne (push/all status).

## 6. Failure modes (MUST)
- Jeśli provider offline: Core MUST hold (nie wysyłać goTarget/forkHeight).
- Jeśli provider zmienia się: Core MUST hold do czasu online.
