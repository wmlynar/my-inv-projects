# Fleet Manager 2.0 — Kontrakty wspólne (v0.5)

Ten plik jest „kanonem kontraktów”, wspólnym dla Core/Gateway/Algorithm/UI.

## 1. Typy bazowe

```json5
{
  // ULID jako string (np. "01JH1B...")
  Ulid: "string",

  RobotId: "string",       // np. "RB-01" (zewnętrzny identyfikator robota)
  SceneId: "string",       // ULID
  TaskId: "string",        // ULID
  CommandId: "string",     // ULID
  StreamId: "string",      // np. "stream_inbound_01"
  WorksiteId: "string",    // np. "PICK_01"

  TimestampMs: 1736160000000, // int64 epoch ms
  Cursor: 123456,             // int64, rosnący monotonicznie w obrębie instancji Core
}
```

## 2. Geometria i kinematyka (w domenie FM)

### 2.1 Pose2D
```json5
{
  xM: 12.34,
  yM: 5.67,
  angleRad: 1.57079632679,
}
```

### 2.2 Velocity2D
```json5
{
  vxMps: 0.5,
  vyMps: 0.0,
  angularSpeedRadS: 0.0,
}
```

## 3. ErrorEnvelope (kanoniczny format błędu)
Wszystkie API HTTP (Core/Gateway/Algorithm) **MUST** zwracać błędy w tym formacie.

```json5
{
  error: {
    code: "validationError",         // enum, patrz niżej
    message: "Unknown field: fooBar",
    details: {
      field: "fooBar",
      expected: ["robotId", "sceneId"],
    },

    // CauseCode: „dlaczego” (patrz Reason Codes)
    causeCode: "UNKNOWN_FIELD",

    // Korelacja i debug (SHOULD)
    traceId: "trace_01JH...",
    requestId: "req_01JH...",
  }
}
```

### 3.1 ErrorEnvelope.code (MUST — zamknięty katalog)
Minimalny katalog (może rosnąć, ale nie zmienia znaczeń istniejących):

- `validationError`
- `notFound`
- `conflict`
- `notAllowed`
- `unauthorized` (poza MVP, ale kod zarezerwowany)
- `forbidden` (poza MVP, ale kod zarezerwowany)
- `rateLimited` (poza MVP, ale kod zarezerwowany)
- `timeout`
- `dependencyUnavailable`
- `internalError`

### 3.2 Mapowanie ErrorEnvelope.code → HTTP status (MUST)
- `validationError` → **400**
- `notFound` → **404**
- `conflict` → **409**
- `notAllowed` → **405**
- `unauthorized` → **401**
- `forbidden` → **403**
- `rateLimited` → **429**
- `timeout` → **504** (jeśli timeout do dependency) lub **408** (jeśli timeout klienta)
- `dependencyUnavailable` → **503**
- `internalError` → **500**

## 4. Reason Codes (kody przyczyn)
Zasada: każdy ważny status w domenie ma `*ReasonCode` (string).
Kody są używane zarówno w UI, jak i do automatycznej diagnostyki.

### 4.1 ReasonCode — wartości bazowe
- `NONE`
- `UNKNOWN`
- `VALIDATION_FAILED`
- `UNKNOWN_FIELD`
- `CONFLICT`
- `STALE_STATE`
- `DEPENDENCY_OFFLINE`
- `NETWORK_ERROR`
- `TIMEOUT`
- `EMERGENCY_STOP`
- `ROBOT_BLOCKED`
- `ROBOT_MANUAL_MODE`
- `ROBOT_LOCALIZATION_LOST`
- `SCENE_NOT_ACTIVE`
- `CONTROL_LEASE_REQUIRED`
- `CONTROL_LEASE_SEIZED`
- `PROVIDER_SWITCHING`
- `COMMAND_REJECTED`
- `COMMAND_ACK_TIMEOUT`
- `COMMAND_EXEC_TIMEOUT`
- `COMMAND_CANCELED`
- `MAP_INVALID`
- `MAP_IMPORT_FAILED`
- `ALGO_TIMEOUT`
- `ALGO_ERROR`

**Uwaga:** katalog może rosnąć, ale istniejące kody MUST zachować znaczenie.

## 5. EventEnvelope (event sourcing + SSE)
Wszystkie zdarzenia domenowe **MUST** być logowane jako `EventEnvelope`.
SSE **MUST** przesyłać dokładnie ten sam format.

```json5
{
  cursor: 123456,
  tsMs: 1736160000123,

  // Kanoniczna nazwa eventu (MUST)
  type: "robotStateUpdated", // patrz katalog poniżej

  // Dla debug / korelacji (SHOULD)
  traceId: "trace_01JH...",
  request: {
    clientId: "ui-traffic-lab-01",
    requestId: "req_01JH...",
  },

  // Payload zależy od type
  payload: { /* ... */ },
}
```

### 5.1 Katalog `EventEnvelope.type` (MVP + fundament)
- `stateSnapshot` (snapshot całego stanu; patrz SSE i snapshoty)
- `sceneImported`
- `sceneActivated`
- `sceneActivationFailed`

**Control Lease (seize control):**
- `controlLeaseChanged`
- `controlLeaseSeized`
- `controlLeaseExpired`
- `robotStateUpdated`
- `robotProviderSwitched`
- `worksiteUpdated`
- `streamUpdated`
- `taskCreated`
- `taskUpdated`
- `taskCanceled`
- `commandCreated`
- `commandUpdated`
- `lockUpdated`
- `reservationUpdated`
- `systemWarning`
- `systemError`

### 5.2 Zasady spójności
- `cursor` MUST rosnąć o 1 dla każdego eventu zapisanego w logu.
- Event log MUST być jedynym źródłem prawdy dla odtwarzania.
- Snapshot MUST zawierać `cursor` odpowiadający ostatniemu eventowi, który obejmuje.

## 6. Kontrakty konfiguracji usług (JSON5)

### 6.1 FleetCoreConfig
```json5
{
  // ścieżki
  dataDir: "./data",
  sceneStoreDir: "./data/scenes",

  // event sourcing
  eventLog: {
    fileRotationMb: 256,
    retentionDays: 14,
    flushEveryEvent: true, // MUST w MVP
  },
  snapshots: {
    intervalMs: 1000,
    retentionCount: 2000,
    writeToDisk: true, // MUST (Twoje wymaganie)
  },

  // tick loop
  tickHz: 10,

  // freshness
  statusAgeMaxMs: 1500,

  // rolling target
  rollingTarget: {
    lookaheadMinDistanceM: 3.0,   // target ma być >= tyle metrów "do przodu" po trasie (SHOULD)
    updateMinIntervalMs: 300,      // nie spamować robota
  },

  // lease / seize
  controlLease: {
    defaultTtlMs: 15000,
    maxTtlMs: 60000,
    allowForceSeize: true,
  },

  // integracje
  gateway: {
    baseUrl: "http://127.0.0.1:8081",
    timeoutMs: 1200,
    retry: { maxAttempts: 3, backoffMs: 200 },
  },
  algorithm: {
    baseUrl: "http://127.0.0.1:8082",
    timeoutMs: 400, // <= 1/tickHz (SHOULD)
    retry: { maxAttempts: 1 },    // Core MUST nie robić wielokrotnych retry na tick (fail fast)
  },
}
```

### 6.2 FleetGatewayConfig
```json5
{
  dataDir: "./data",
  captureDir: "./data/capture",

  http: { listenHost: "0.0.0.0", listenPort: 8081 },

  providers: {
    internalSim: { enabled: true },

    // real robot via Robokit TCP framing (RoboCore/Robokit)
    robocore: {
      enabled: true,
      robots: {
        "RB-01": { host: "10.0.0.11", ports: { state: 19204, ctrl: 19205, task: 19206, other: 19210, push: 19301 } },
      },
      tcp: {
        connectTimeoutMs: 800,
        requestTimeoutMs: 1000,
        maxConcurrentPerRobot: 4,
        circuitBreaker: { failureThreshold: 5, openMs: 5000 },
        reconnect: { enabled: true, baseDelayMs: 500, maxDelayMs: 10000, backoffFactor: 2.0 },
      },
    },

    // robokit-sim (zewnętrzny symulator) przez ten sam protokół TCP
    robokitSim: {
      enabled: true,
      robots: {
        "RB-01": { host: "127.0.0.1", ports: { state: 19204, ctrl: 19205, task: 19206, other: 19210, push: 19301 } },
      },
    },
  },
}
```

### 6.3 AlgorithmServiceConfig
```json5
{
  http: { listenHost: "0.0.0.0", listenPort: 8082 },
  algo: {
    id: "algo_mvp_v0_1",
    tickHzMax: 20,
    // opcjonalne flagi debug
    debug: { emitExplain: true },
  },
}
```

## 7. Limits & defaults (tabela)
Poniżej twarde limity i domyślne wartości. W MVP można trzymać w configu, ale spec mówi,
co jest „bezpiecznym” defaultem.

| Parametr | Domyślnie | Limit | Uwagi |
|---|---:|---:|---|
| `tickHz` | 10 | 1..50 | algorithm timeout SHOULD < 1/tick |
| `statusAgeMaxMs` | 1500 | 200..5000 | stale status => hold |
| `rollingTarget.lookaheadMinDistanceM` | 3.0 | 0.5..20 | zależne od mapy |
| `rollingTarget.updateMinIntervalMs` | 300 | 50..5000 | anty-spam |
| `snapshots.intervalMs` | 1000 | 100..10000 | MUST na dysk |
| `eventLog.retentionDays` | 14 | 1..365 | rotacja + archiwizacja |
| `gateway.timeoutMs` | 1200 | 50..10000 | HTTP |
| `robocore.tcp.requestTimeoutMs` | 1000 | 50..5000 | TCP do robota |
