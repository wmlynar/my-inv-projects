# Fleet Manager 2.0 — Proxy/Recorder (dev tool) (v0.5)

Proxy/Recorder to niezależne oprogramowanie do podsłuchu i zapisu komunikacji
między:
- Roboshop ↔ robot
- Roboshop ↔ RDS (gotowy fleet manager)
- Core/Gateway ↔ robot (w trybie debug)

## 1. Wymagania (MUST)
- Tool MUST działać niezależnie od Fleet Core/Gateway.
- Tool MUST mieć konfigurowalne:
  - porty nasłuchu,
  - adresy upstream,
  - katalog zapisu,
  - tryb hexdump/pcap/jsonl.
- Tool MUST obsłużyć wiele sesji jednocześnie.

## 2. Minimalny kontrakt konfiguracji (JSON5)
```json5
{
  listeners: [
    {
      name: "roboshop_to_robot_rb01_task",
      listen: { host: "0.0.0.0", port: 30006 },
      upstream: { host: "10.0.0.11", port: 19206 },
      capture: { dir: "./capture/rb01/task", format: "jsonl+pcap" },
    },
  ],
}
```

## 3. Wymagania zapisu (MUST)
- Każda ramka MUST być zapisana z timestampem.
- Dla RoboCore/Robokit tool SHOULD dekodować nagłówek (apiNo, seq, bodyLength, jsonSize) do JSONL.
- W razie błędu parsowania tool MUST zachować raw bytes (nie gubić).

## 4. Integracja z testami (SHOULD)
- Golden traces z Proxy/Recorder są wejściem do testów integracyjnych gateway (replay).
- Format paczki golden trace opisany w `16_obserwowalnosc_i_replay.md`.

## 5. Integracja z robot-controller (dev/test)
- `robot-controller` SHOULD umieć odtwarzać capture z Proxy/Recorder (replay) jako test „czy rozumiemy protokół”.
- Capture SHOULD być współdzielone: to samo wejście do regresji `fleet-gateway` i do smoke-testów `robot-controller`.
