# Fleet Manager 2.0 — Port algorytmu i API Algorithm Service (v0.5)

Ten plik jest kontraktem pomiędzy Fleet Core a implementacją algorytmu.
Zakładamy, że algorytm jest osobnym modułem/usługą (AI-friendly, niezależny development),
a komunikacja odbywa się po HTTP.

## 1. Wymagania dla algorytmu (MUST)
- Algorytm MUST być deterministyczny dla danego wejścia (`AlgorithmInputSnapshot`).
- Algorytm MUST być side-effect free (brak IO do świata zewnętrznego jako część decyzji).
- Algorytm MUST zwracać decyzję w czasie < `algorithm.timeoutMs`.
- Jeśli algorytm nie zdąży: Core MUST przejść w tryb fail-safe (hold) dla robotów.

## 2. Kontrakty danych

### 2.1 AlgorithmSceneContext (statyczny kontekst sceny)
Core może cache’ować kontekst i przesyłać go albo raz (init), albo w każdym ticku (MVP dopuszcza oba).

```json5
{
  scene: {
    manifest: { /* SceneManifest */ },
    graph: { /* SceneGraph (z geometrią DegenerateBezier!) */ },
  },

  worksites: [ /* Worksite[] */ ],
  streams: [ /* StreamDefinition[] */ ],

  // definicje ActionPoint akcji (np. widły)
  actionPoints: [ /* ActionPointDefinition[] */ ],

  // statyczne roboty
  robots: [ /* RobotConfig[] */ ],
}
```

### 2.2 AlgorithmInputSnapshot (tick)
```json5
{
  tick: 12345,
  tsMs: 1736160000123,

  sceneId: "scene_01JH...",

  // runtime state
  robots: [ /* RobotRuntimeState[] (znormalizowane) */ ],
  tasks: [ /* Task[] (lub tylko aktywne) */ ],
  locks: [ /* Lock[] */ ],

  // dodatkowe dane
  lastDecisions: [
    { robotId: "RB-01", lastTargetNodeId: "LM2", tsMs: 1736160000000 },
  ],

  // allowlist debug/trace (MAY)
  debug: { traceId: "trace_01JH..." },
}
```

### 2.3 AlgorithmDecision (wyjście)
**Kluczowa zmiana v0.4:** Rolling target jest wskazywany jako **NodeRef** (`LocationMark` lub `ActionPoint`).

```json5
{
  tick: 12345,

  robotCommands: [
    {
      robotId: "RB-01",
      command: {
        type: "setRollingTarget",
        targetRef: { nodeId: "LM2" },   // MUST: nodeId istnieje w SceneGraph i jest LM/AP
        hold: false,
        holdReasonCode: "NONE",

        // debug
        routeId: "route_01JH...",
        explain: "Next LM ahead by 3.2m",
      },
    },
  ],

  // opcjonalne zmiany domenowe (MAY, zależnie od architektury algorytmu)
  taskUpdates: [
    {
      taskId: "task_01JH...",
      patch: { status: "assigned", assignedRobotId: "RB-01" },
    },
  ],

  locksRequested: [
    { robotId: "RB-01", resourceType: "edgeGroup", resourceId: "LM2<->LM3", ttlMs: 5000 },
  ],

  meta: { algoId: "algo_mvp_v0_1" },
}
```

**Walidacje (MUST):**
- `targetRef.nodeId` MUST istnieć w `scene.graph.nodes`.
- Node MUST mieć `className` ∈ {`LocationMark`, `ActionPoint`}.
- Jeśli `hold=true`, Core MUST NOT dispatchować komend ruchu.

## 2.4 Kanoniczne mapowanie decyzji algorytmu na komendy domenowe (MUST)

W systemie istnieją dwa poziomy „komend”:
- **AlgorithmRobotCommand** (wewnętrzny język algorytmu): np. `setRollingTarget`, `hold`.
- **CommandRecord** (kanoniczna komenda domenowa Core → Gateway): np. `goTarget`, `stop`, `forkHeight`.

To mapowanie jest wykonywane WYŁĄCZNIE w Fleet Core (single source of truth), zgodnie z regułami:

1) `setRollingTarget(targetRef)` → `CommandRecord.type = "goTarget"`, `payload.targetRef = targetRef`.
   - Core MUST deduplikować: jeśli ostatni efektywnie wysłany `targetRef` dla robota jest identyczny, Core MUST NOT tworzyć nowego `CommandRecord`.
   - Core MUST stosować rate-limit: nie częściej niż `FleetCoreConfig.rollingTarget.updateMinIntervalMs`.
   - `targetRef.nodeId` MUST wskazywać węzeł `LocationMark` lub `ActionPoint`.

2) `hold=true` → Core MUST wstrzymać ruch (brak nowych komend ruchu) i utrzymać robota w stanie `navigation.state = paused|blocked` zgodnie z polityką.

3) (MVP) Algorytm nie wysyła bezpośrednio komend wideł. Widełki są realizowane jako kroki TaskRunner (`TaskStep.type=forkHeight`) oraz mapowane w Core na `CommandRecord.type=forkHeight` (patrz `05_*` i `10_*`).

Uwaga praktyczna: jeśli w przyszłości algorytm będzie generował jawne akcje wideł, to Core MUST mapować je do `CommandRecord` w analogiczny sposób jak powyżej (z pełnym audytem w event log).

## 3. API HTTP Algorithm Service (MUST)

### 3.1 GET /algo/v1/health
- Odpowiedź: `200 { status: "ok" }` lub `503`.

### 3.2 POST /algo/v1/decide
- Request body: `AlgorithmInputSnapshot`
- Response body: `AlgorithmDecision`
- Timeout: wg `FleetCoreConfig.algorithm.timeoutMs`.

#### Przykład request (JSON5 w spec, realnie JSON)
```json5
{
  tick: 12345,
  tsMs: 1736160000123,
  sceneId: "scene_01JH...",
  robots: [
    { robotId: "RB-01", pose: { xM: 10.0, yM: 3.0, angleRad: 0.0 }, navigation: { state: "idle" } },
  ],
  tasks: [],
  locks: [],
}
```

#### Przykład response
```json5
{
  tick: 12345,
  robotCommands: [
    { robotId: "RB-01", command: { type: "setRollingTarget", targetRef: { nodeId: "LM2" }, hold: false } },
  ]
}
```

### 3.3 POST /algo/v1/initScene (SHOULD; opcjonalne)
Jeśli chcemy przesyłać `AlgorithmSceneContext` raz:
- request: `AlgorithmSceneContext`
- response: `{ ok: true }`

MVP MAY pominąć i wysyłać kontekst w każdym ticku (kosztem większych payloadów).

## 4. Failure modes (MUST)
- Jeśli Algorithm Service zwraca błąd (`5xx` lub `4xx`): Core MUST ustawić hold dla robotów i emitować `systemError` z `causeCode=ALGO_ERROR`.
- Jeśli timeout: Core MUST hold + `causeCode=ALGO_TIMEOUT`.
- Core MUST logować request/response algorytmu do event log (lub do osobnego `algo.log.jsonl`) w trybie debug.

## 5. Future-proof
- Kontrakty algorytmu mają osobną wersję (`algoId`, `contractsVersion`) i mogą ewoluować niezależnie.
- Core MAY wspierać wiele algorytmów i routing ruchu na podstawie `scene.manifest` lub config.
