# Fleet Manager 2.0 — Kontrakty: scena i mapa (v0.5)

## 1. Scene Package (format paczki sceny)

### 1.1 Struktura katalogu (MUST)
Scene Package **MUST** być katalogiem (w storage Core) lub zipem (na wejściu importu) o strukturze:

```text
scene/
  manifest.json5              # MUST
  map/
    raw.smap                  # SHOULD (oryginał)
    graph.json                # MUST (kanoniczny SceneGraph; wynik Map Compiler)
    assets/                   # MAY (np. obrazki tła dla UI)
  config/
    robots.json5              # MAY (konfiguracja robotów)
    worksites.json5           # MUST (dla MVP)
    streams.json5             # MUST (dla MVP)
    actionPoints.json5        # MAY (akcje AP, np. widły)
  README.md                   # MAY (opis sceny)
```

### 1.2 Ochrona przed zip-bomb i gigantycznymi plikami (MUST)
Import zip **MUST**:
- limitować liczbę plików,
- limitować sumaryczny rozmiar po rozpakowaniu,
- odrzucać ścieżki typu `../` (zip-slip).

### 1.3 SceneManifest (MUST)
```json5
{
  sceneId: "scene_01JH1B...",
  sceneName: "warehouse_nowy_styl",
  createdTsMs: 1736160000000,

  // wersje
  contractsVersion: "fm-contracts-v0.4",
  mapFormat: "smap+graphjson-v1",

  // checksums (SHOULD)
  checksums: {
    "map/graph.json": "sha256:...",
    "map/raw.smap": "sha256:...",
  },

  // opis opcjonalny
  meta: {
    author: "inovatica",
    notes: "MVP scene",
  },
}
```

## 2. SceneGraph (kanoniczny graf mapy)

**Kluczowa zmiana v0.4:** geometria krawędzi jest częścią kontraktu i jest dostępna dla algorytmu.
Geometria pochodzi z `.smap`, a w `graph.json` jest reprezentowana m.in. jako `DegenerateBezier`.

### 2.1 Struktura `graph.json` (MUST)
```json5
{
  meta: {
    mapName: "mapa_nowy_styl",
    resolutionM: 0.02, // jeśli źródło ma inne jednostki, Map Compiler MUST przeliczyć do metrów
    source: "map/raw.smap",
  },

  nodes: [ /* Node[] */ ],
  edges: [ /* Edge[] */ ],

  // elementy wizualne dla UI (MAY)
  lines: [ /* FeatureLine[] */ ],
  areas: [ /* FeatureArea[] */ ],
}
```

## 3. Węzły (Nodes)

### 3.1 Wspólne pola Node (MUST)
```json5
{
  id: "LM1",                  // unikalny w obrębie graph
  className: "LocationMark",  // enum: LocationMark | ActionPoint | ParkPoint | ChargePoint | ...
  pos: { xM: 31.733, yM: 4.833 },
  props: { /* external/raw */ },

  // mapowanie identyfikatorów do systemów zewnętrznych (MAY, ale RECOMMENDED)
  // Uwaga: NodeId w FM nie musi być tym samym, co „station id” na robocie.
  externalRefs: {
    // identyfikator używany w protokole RoboCore/Robokit dla goTarget(id)
    robocoreStationId: "LM1",

    // jeśli kiedykolwiek będą rozjazdy Robokit vs RoboCore
    robokitStationId: "LM1",
  },

  // dane po kompilacji (MAY, ale w praktyce SHOULD jeśli algorytm tego potrzebuje)
  propsCompiled: { /* derived */ },
}
```

### 3.2 LocationMark
- `className = "LocationMark"`
- Semantyka: punkt nawigacyjny, może służyć jako rolling target.

### 3.3 ActionPoint
- `className = "ActionPoint"`
- Semantyka: punkt akcji, może służyć jako rolling target.
- Dodatkowo: akcje AP mogą być opisane w `config/actionPoints.json5` (patrz niżej).

## 4. Krawędzie (Edges) i geometria

### 4.1 Edge (MUST)
```json5
{
  id: "LM1-LM2",
  className: "DegenerateBezier",   // klasa geometrii (z mapy)
  start: "LM1",
  end: "LM2",

  // geometria w metrach (MUST)
  startPos: { xM: 31.733, yM: 4.833 },
  endPos: { xM: 31.650, yM: 4.833 },
  controlPos1: { xM: 31.700, yM: 4.850 },
  controlPos2: { xM: 31.680, yM: 4.820 },

  props: { /* external/raw */ },

  // derived (Fix z recenzji: to musi być w kontrakcie, a nie tylko opisem)
  propsCompiled: {
    direction: "bidirectional",       // bidirectional | forwardOnly | backwardOnly
    corridorWidthM: 4.0,              // width > 0 => miejsce potencjalnego omijania (future)
    lengthM: 12.34,                   // arc length po krzywej (MUST wyliczone przez Map Compiler)
    forbiddenRotAngleRad: 1.5707963,  // jeśli występuje w mapie
  },
}
```

### 4.2 Wymagania dot. geometrii (MUST)
- Map Compiler MUST zachować geometrię źródłową (control points) w `graph.json`.
- Map Compiler MUST wyliczyć `lengthM` deterministycznie.
- Algorytm MUST mieć dostęp do geometrii (wprost) i/lub do próbkowanej polilinii (jeśli dostarczona).

**Rekomendacja (SHOULD):** Map Compiler dodaje pole `geometrySamples`:
```json5
{
  geometrySamples: {
    stepM: 0.2,
    points: [
      { xM: 31.733, yM: 4.833 },
      { xM: 31.700, yM: 4.845 },
      // ...
    ]
  }
}
```
To upraszcza symulację, wizualizację i algorytmy (bez implementacji Béziera w każdym miejscu).

## 5. ActionPoint actions (np. widły)

### 5.1 `config/actionPoints.json5` (MAY, ale dla wideł w MVP: SHOULD)
```json5
[
  {
    actionPointId: "AP_PICK_01",
    actionType: "forkHeight",

    // parametry w metrach (Twoje wymaganie: "z jakiej wysokości na jaką")
    params: {
      fromHeightM: 0.10,        // MAY (walidacja startu)
      toHeightM: 1.20,          // MUST
      toleranceM: 0.02,         // SHOULD
      timeoutMs: 20000,         // SHOULD
    },

    meta: { label: "Pick: forks up" },
  },
  {
    actionPointId: "AP_DROP_01",
    actionType: "forkHeight",
    params: { toHeightM: 0.10 },
    meta: { label: "Drop: forks down" },
  },
]
```

### 5.2 Walidacja (MUST)
- `actionPointId` MUST istnieć w `SceneGraph.nodes` jako `className = "ActionPoint"`.
- `toHeightM` MUST być >= 0.
- `fromHeightM`, jeśli podane, MUST być >= 0.

## 6. FeatureLine / FeatureArea (UI)
To elementy wizualne i/lub semantyczne (strefy). UI może je renderować,
a Core/Algorytm mogą używać jako soft constraints w przyszłości.

Kontrakt jest kompatybilny wstecz: `lines[]` i `areas[]` są opcjonalne.

## 7. Dynamiczna zmiana mapy i konfiguracji (SHOULD)
- Core MAY przyjmować patch sceny (np. update worksites/streams) bez zmiany mapy.
- Zmiana `graph.json` (mapy) w trakcie pracy jest bardziej ryzykowna; jeśli wprowadzana:
  - Core MUST wykonać pełną procedurę Scene Activation (patrz `07_*` i `08_*`),
  - Core MUST anulować/holdować aktywne komendy i zaktualizować locki.

Szczegóły: `07_semantyka_runtime_i_maszyny_stanow.md` + `14_map_compiler.md`.
