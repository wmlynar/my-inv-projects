# Fleet Manager 2.0 — Obserwowalność i replay (v0.5)

Wymaganie nadrzędne: system MUST dać się odtworzyć po fakcie („co się stało?”).

## 1. Event log (MUST: na dysk)
- Core MUST zapisywać wszystkie `EventEnvelope` do plików JSONL na dysk.
- Core MUST flushować po każdym evencie w MVP (`flushEveryEvent=true`).

Proponowana struktura:
```text
data/
  events/
    events_000001.jsonl
    events_000002.jsonl
  snapshots/
    snapshot_000123456.json
    snapshot_000123999.json
```

Każdy wiersz `events_*.jsonl` to jeden `EventEnvelope`.

## 2. Snapshoty (MUST: na dysk)
- Snapshot MUST zawierać:
  - `schemaVersion`
  - `cursor`
  - pełny stan `/state` (lub stan kanoniczny)
  - `tsMs`
- Snapshoty MUST być rotowane (`retentionCount`).
- Snapshoty MUST być używane do szybkiego restartu Core.

Przykład:
```json5
{
  schemaVersion: "state-v0.4",
  cursor: 123456,
  tsMs: 1736160000123,
  state: { /* jak GET /state */ }
}
```

## 3. Replay (MUST)
- Core MUST mieć tryb uruchomienia `--replay <dir>`:
  - ładuje snapshot,
  - odtwarza event log,
  - pozwala krokować ticki (opcjonalnie).
- Replay MUST być deterministyczny (ta sama sekwencja eventów → ten sam stan).

## 4. Golden traces (SHOULD)
„Golden trace” to artefakt testowy i debugowy:
```text
trace/
  scene/...
  events.jsonl
  snapshots/...
  expected.json5
  README.md
```

`expected.json5` zawiera asercje, np.:
```json5
{
  asserts: [
    { atCursor: 123900, expect: { robotId: "RB-01", navigationState: "blocked" } },
  ]
}
```

## 5. Gateway capture (MUST w debug, SHOULD w test)
- Gateway SHOULD zapisywać capture TCP:
  - raw bytes,
  - dekodowany header,
  - payload JSON (jeśli parsowalny).
- Capture MUST mieć korelację z `commandId` (jeśli dotyczy).

## 6. Monitoring runtime (SHOULD)
- metryki: tick latency, algo latency, gateway latency, robot offline counts
- health endpoints + readiness
- w przyszłości: tracing (poza MVP, ale `traceId` w kontraktach już jest)

## 7. Incident workflow (SHOULD)
- Każdy błąd integracyjny powinien kończyć się paczką: `{scene + events + snapshots + gateway-capture}`.
- Proxy/Recorder wspiera zbieranie surowych ramek (`15_*`).
