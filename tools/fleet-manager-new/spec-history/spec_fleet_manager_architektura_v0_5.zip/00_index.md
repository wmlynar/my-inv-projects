# Fleet Manager 2.0 — Specyfikacja architektury (v0.5)

**Data:** 2026-01-06  
**Status:** draft „MVP-ready” (docelowo: produkcyjny)  
**Zakres tego pakietu:** architektura i kontrakty (bez pełnej specyfikacji algorytmu; algorytm ma osobny dokument)

---

## Część 1 — Prompt i cel dokumentu

### Prompt pierwotny (kontekst)
(oryginalny opis problemu i oczekiwań — zachowany, bo jest częścią wymagań)

> Fleet manager to program do zarządzania autonomicznymi wózkami widłowymi.  
> Chcę go przepisać, ale podoba mi się UI.  
> Projekt ma być **bardzo modułowy**, żeby można było pracować nad częściami niezależnie, porozumiewając się przez API.  
> Frontend ma być tylko jednym z klientów — system ma działać headless, ma wspierać wiele frontendów naraz.  
> Ma istnieć silnik/nawigacja, dynamiczna zmiana mapy i konfiguracji (scena).  
> Integracje: Roboshop (upload mapy), RoboCore/Robokit (komunikacja z robotami), wewnętrzna symulacja wielu robotów + możliwość podmiany jednego robota na symulowanego przez RoboCore/Robokit lub na prawdziwego.  
> Wymagane: elegancki design, czytelne interfejsy, odporność na błędy sieci, bardzo profesjonalna dokumentacja.  
> Rolling target: robot dostaje cel „z przodu” na trasie, robot lokalnie planuje.  
> Obstacle avoidance: docelowo po stronie robota, ale w MVP wystarczy wykrywać blokadę i chęć wejścia w tryb omijania.

### Prompt do wersji v0.4 (ten, na podstawie którego powstała aktualizacja)
(zebrane instrukcje i uwagi z recenzji + Twoje doprecyzowania)

> Zastosuj się do wszystkich uwag z recenzji specyfikacji architektury v0.3.  
> Wprowadź ważne zmiany:  
> - Algorytm musi umieć wczytywać geometrię; geometria jest w pliku `.smap` (w `graph.json` jako `DegenerateBezier`).  
> - Robot jest sterowany **rolling target**, ale target to nie (x,y). Target to **LocationMark** albo **ActionPoint**.  
> - Podnoszenie wideł to **ActionPoint** z parametrami (np. z jakiej wysokości na jaką). Opisz jakie ramki protokołu RoboCore/Robokit są do tego użyte.  
> - Wprowadź poprawki wynikające z przeglądu kompletności po podziale na pliki.  
> - Podziel specyfikację na mniejsze dokumenty (np. contracts, core_api, gateway_api, …).

### Prompt do wersji v0.5 (ten, na podstawie którego powstała aktualizacja)
(najważniejsze uwagi z recenzji v0.4 + Twoje doprecyzowania)

> Wykonaj wszystko z recenzji v0.4: przywróć pełny obraz systemu i omówienie KAŻDEGO komponentu.
> Przejrzyj poprzednie wersje i jeśli coś zniknęło, dodaj to z powrotem.
> Dodaj diagramy całości i przepływów.
> Dodaj komponent „robot-controller” do testowego sterowania robotem przez Robokit/RoboCore (na bazie capture z proxy).
> Nie dziel dokumentów dalej (zamiast nowych plików: uzupełnij istniejące, szczególnie 02).

---

## Część 2 — Jak czytać tę specyfikację

### Kanon i źródła prawdy (ważne!)
Ta specyfikacja jest celowo rozbita na trzy „warstwy prawdy”:

1) **Kanon kontraktów (Contracts)** — struktury danych, enumy, reason codes, przykłady payloadów (JSON5).  
   → pliki `03_*`–`06_*`

2) **Kanon zachowania systemu (Runtime semantics)** — procedury i maszyny stanów:  
   scene activation, lease/seize control, lifecycle komend, hot-switch providera, retry/timeout.  
   → plik `07_*` + wybrane rozdziały w `11_*`, `16_*`

3) **Kanon API (Transport)** — endpointy HTTP, statusy, idempotencja, SSE.  
   → pliki `08_*`, `09_*`, `06_*` (algo), `10_*` (roboty)

Jeśli implementacja koliduje z opisem, obowiązuje kolejność: **Contracts → Runtime semantics → API**.

---

## Struktura plików (v0.5)

**Wejściowy plik dla czytelnika:** `00_index.md` (ten plik)

1. `01_konwencje_i_glosariusz.md`
2. `02_architektura_wysokopoziomowa.md` *(zawiera też normatywną specyfikację komponentów + diagramy)*
3. `03_kontrakty_wspolne.md`
4. `04_kontrakty_scena_i_mapa.md`
5. `05_kontrakty_domena.md`
6. `06_port_algorytmu_i_api_algorytmu.md`
7. `07_semantyka_runtime_i_maszyny_stanow.md`
8. `08_api_fleet_core.md`
9. `09_api_fleet_gateway.md`
10. `10_protokol_robocore_robokit.md`
11. `11_symulacja_i_hot_switch_providerow.md`
12. `12_repozytorium_i_podzial_na_projekty.md` *(uwzględnia też robot-controller)*
13. `13_integracja_roboshop_bridge.md`
14. `14_map_compiler.md`
15. `15_proxy_recorder.md`
16. `16_obserwowalnosc_i_replay.md`
17. `17_strategia_testow.md`
18. `18_scenariusze_e2e.md`
19. `19_mvp_definicja.md`
20. `20_ryzyka_i_pulapki.md`
21. `99_rzeczy_usuniete_lub_odroczone.md`

---

## Changelog v0.5 (najważniejsze zmiany względem v0.4)

- **Przywrócono pełny obraz systemu:** `02_architektura_wysokopoziomowa.md` zawiera normatywne specyfikacje każdego komponentu (Core/Gateway/Algo/UI + narzędzia) oraz diagramy C4/flow/sequence.
- **Dodano komponent `robot-controller` (dev/test):** minimalny klient RoboCore/Robokit do weryfikacji rozumienia protokołu i sterowania robotem/symulatorem na podstawie capture z `proxy-recorder`.
- **Ujednolicono taksonomię komend Algo→Core→Gateway:** jawne mapowanie `setRollingTarget` → `CommandRecord.type=goTarget`, deduplikacja, idempotencja i limity wysyłania.
- **Uściślono mapowanie ID węzłów do identyfikatorów zewnętrznych:** dodano `Node.externalRefs.*` w `04_kontrakty_scena_i_mapa.md`.

## Changelog v0.4 (najważniejsze zmiany względem v0.3)

- **Rolling Target:** `setRollingTarget.targetRef` to **LocationMark/ActionPoint**, nie (x,y).  
  Gateway tłumaczy to na RoboCore `goTarget(id)` (API 3051).  
- **Akcje wideł:** dodany kontrakt akcji `forkHeight` jako ActionPoint + mapowanie na RoboCore `forkHeight(height)` (API 6040) oraz `forkStop` (6041).  
- **Geometria:** doprecyzowano wymagania Map Compiler i kontraktów, że geometria krawędzi (`DegenerateBezier`) jest częścią kanonicznego `SceneGraph` i jest dostępna dla algorytmu.  
- **SSE:** ujednolicono semantykę: SSE niesie **zawsze** `EventEnvelope`, snapshot to `EventEnvelope.type = "stateSnapshot"`. Doprecyzowano `fromCursor` vs `Last-Event-ID`.  
- **Konfiguracja:** dodano formalne kontrakty `FleetCoreConfig`, `FleetGatewayConfig`, `AlgorithmServiceConfig` oraz tabelę `limits & defaults`.  
- **Maszyny stanów:** dopisano jawne state machines dla: `CommandRecord`, `ControlLease`, `SceneActivation`, `TaskRun`.  
- **Porządek dokumentu:** rozdzielono contracts/semantykę/API na osobne pliki (łatwiejsze dla ludzi i AI).

---

## Notatka o bezpieczeństwie i zakresie (MVP)
Security (authN/authZ, TLS, multi-tenant) jest **poza MVP** — ale interfejsy są projektowane tak,
żeby w przyszłości dało się to dołożyć bez łamania kontraktów.
Szczegóły w `19_mvp_definicja.md` i `99_rzeczy_usuniete_lub_odroczone.md`.
