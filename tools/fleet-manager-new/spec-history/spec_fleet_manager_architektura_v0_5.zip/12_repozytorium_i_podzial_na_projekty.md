# Fleet Manager 2.0 — Repozytorium i podział na projekty (v0.5)

Cel: modularność + możliwość niezależnej pracy (w tym pracy AI) nad komponentami.

## 1. Proponowany monorepo layout (SHOULD)
```text
repo/
  apps/
    fleet-core/              # HTTP /api/v1
    fleet-gateway/           # HTTP /gateway/v1
    algorithm-service/       # HTTP /algo/v1
    ui-frontend/             # WWW
    roboshop-bridge/         # opcjonalnie
    proxy-recorder/          # dev tool
    robot-controller/        # dev/test: sterowanie RoboCore/Robokit (reverse engineering)
    robokit-sim/             # zewnętrzny symulator (jeśli w repo)
  packages/
    contracts/               # TS/JSON definicje kontraktów + przykłady
    map-compiler/            # parser+kompilacja .smap -> graph.json
    provider-internal-sim/   # silnik symulacji (może być użyty w gateway)
    adapters-robokit/        # TCP framing + client
    common/                  # utilsy (ULID, JSON, logger, ...)
  scenes/
    warehouse_nowy_styl/     # scene package katalog
  docs/
    architecture/            # ta specyfikacja (markdown)
    algorithm/               # spec algorytmu (osobno)
```

## 2. Granice (MUST)
- `contracts/` MUST być niezależnym pakietem, wersjonowanym, używanym przez wszystkie usługi.
- `fleet-core` MUST nie importować kodu TCP/protocol (to jest w gateway).
- `fleet-gateway` MUST nie implementować logiki domenowej (task assignment, locks) — to jest w core.
- `algorithm-service` MUST nie pisać do storage Core i MUST nie gadać z gateway (tylko Core→Algo).

## 3. Testowalność i mocki (MUST)
- Każdy projekt MUST mieć testy jednostkowe (piramida testów).
- `fleet-core` MUST mieć testy z mock gateway + mock algo.
- `fleet-gateway` MUST mieć testy integracyjne z robokit-sim.
- `algorithm-service` MUST mieć testy deterministyczne na golden input/output.

Szczegóły: `17_strategia_testow.md`.
