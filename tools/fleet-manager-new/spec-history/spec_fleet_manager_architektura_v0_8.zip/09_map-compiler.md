# map-compiler — Specyfikacja komponentu (v0.8)

## 1. Rola w systemie (MUST)
`map-compiler` jest deterministycznym narzędziem do kompilacji map:
- wejście: `.smap` (źródło) oraz opcjonalne pliki pomocnicze,
- wyjście: kanoniczny `graph.json` (`SceneGraph`) w metrach, z zachowaną geometrią (m.in. `DegenerateBezier`) i wyliczonym `lengthM`.

Algorytm MUST mieć dostęp do geometrii krawędzi (to jest wymaganie).

## 2. Zakres i odpowiedzialności (normatywnie)
#### Scope
Map Compiler jest narzędziem deterministycznym: bierze `.smap` i produkuje kanoniczny `SceneGraph` w `graph.json`.

Map Compiler MUST:
- zachować geometrię źródłową (dla `DegenerateBezier`) i przeliczyć ją do metrów,
- wyliczyć `lengthM` deterministycznie,
- (SHOULD) wygenerować `geometrySamples` dla łatwej symulacji i wizualizacji,
- dostarczyć testy regresji (golden files) dla map.

Related: `04_*`, `14_*`, `17_*`.

## 3. Interfejsy
- CLI: `map-compiler compile --input raw.smap --output graph.json [--config ...]`
- Biblioteka: (MAY) funkcje `compileSmapToSceneGraph(...)`

## 4. Testy (MUST)
- Golden tests: `.smap` → oczekiwane `graph.json` (deterministycznie).
- Walidacje: spójność node/edge, długości, jednostki.

---

## Załącznik A — Map Compiler (verbatim z v0.7)
# Fleet Manager 2.0 — Map Compiler (v0.7)

Map Compiler to narzędzie (CLI/biblioteka), które tworzy kanoniczny `SceneGraph` z mapy `.smap`.

## 1. Wejścia / wyjścia (MUST)
Input:
- `.smap` (źródło geometrii)
- opcjonalne dodatkowe pliki (np. nazwy warstw, metadane)

Output:
- `map/graph.json` zgodny z `04_kontrakty_scena_i_mapa.md`.

## 2. Wymagania deterministyczności (MUST)
- Dla tego samego `.smap` wynik `graph.json` MUST być identyczny (bitwise), chyba że zmieniono wersję kompilatora.
- Kompilator MUST mieć `compilerVersion` w `meta` (SHOULD), np. `meta.compilerVersion = "map-compiler-0.4.0"`.

## 3. Geometria (MUST)
- Kompilator MUST zachować geometrię krawędzi, w tym `DegenerateBezier` (control points).
- Kompilator MUST wyliczać:
  - `lengthM` (arc length, deterministycznie),
  - `direction` (z props mapy),
  - `corridorWidthM` (z props width; jeśli brak to 0),
  - inne derived pola potrzebne algorytmowi (np. forbiddenRotAngleRad), jeśli istnieją w źródle.

## 4. Konwersja jednostek (MUST)
- Jeśli `.smap` używa innej skali: kompilator MUST przeliczyć do metrów (`xM`, `yM`).
- `meta.resolutionM` MUST odzwierciedlać końcową rozdzielczość.

## 5. Walidacje (MUST)
Kompilator MUST wykrywać i raportować:
- brakujące węzły referencjonowane przez krawędzie,
- duplikaty id,
- NaN/Infinity,
- puste grafy.

Raport walidacji SHOULD zawierać `causeCode` oraz listę błędów.

## 6. Opcjonalne próbkowanie geometrii (SHOULD)
Kompilator SHOULD dodawać `geometrySamples` na krawędziach (patrz `04_*`),
aby:
- uprościć symulację,
- uprościć wizualizację,
- uniknąć duplikowania implementacji Béziera w wielu modułach.

## 7. Testy Map Compiler (MUST)
- testy jednostkowe dla parsera `.smap`,
- testy deterministyczności,
- testy kompatybilności z `graph.json` (np. z dołączonym `graph.json` jako golden).

Szczegóły: `17_strategia_testow.md`.
