# ui-frontend — Specyfikacja komponentu (v0.8)

## 1. Rola w systemie (MUST)
`ui-frontend` jest klientem (WWW) do obserwacji i sterowania. System MUST działać headless; UI jest tylko jednym z klientów.
Wiele instancji UI może obserwować równolegle, ale mutacje wymagają `ControlLease` (seize control).

## 2. Zakres i odpowiedzialności (normatywnie)
#### Scope
UI jest klientem: renderuje mapę, roboty, worksites/streams/tasks, umożliwia przejęcie kontroli (lease) i wykonywanie mutacji przez Core.

#### Responsibilities
UI MUST:
- łączyć się tylko z Fleet Core (nigdy bezpośrednio z Gateway),
- subskrybować SSE i budować lokalny stan jako funkcję `stateSnapshot + delty`,
- obsługiwać Control Lease:
  - pokazywać kto ma kontrolę,
  - umożliwiać `seize`, `renew`, `release`,
  - w trybie viewer nie wykonywać mutacji,
- być odporne na reconnect SSE (wznawianie od `cursor`).

UI MUST implementować mechanizm „seize control”:
- instancja UI, która wykonuje `seize`, wywłaszcza poprzedniego operatora;
- UI MUST traktować utratę lease jako natychmiastowe przejście w read-only.

UI SHOULD:
- mieć czytelne debug widoki: locki, trasy, rolling target, bieżące komendy, reason codes.

Related: `03_*`, `07_*`, `08_*`.

## 3. Interfejsy
- UI komunikuje się WYŁĄCZNIE z `fleet-core` po HTTP+SSE.
- UI MUST implementować reconnect SSE i odbudowę stanu z `stateSnapshot` + delty.
- UI MUST być „read-only” bez ważnego lease.

## 4. Wymagania UX/Debug (SHOULD)
- Widok mapy + roboty + worksites/streams/tasks.
- Widoki debug: current provider, current command, rolling target, reason codes, locki/rezerwacje (gdy włączone).

## 5. Konfiguracja uruchomieniowa (MVP)
UI MUST dać się skonfigurować co najmniej przez:
- `CORE_BASE_URL` (np. `http://localhost:8080/api/v1`)
- `SSE_URL` (np. `http://localhost:8080/api/v1/events/stream`)

## 6. Testy (MUST)
- Jednostkowe: redukcja stanu (snapshot + eventy), formatowanie mapy, walidacje payloadów.
- Integracyjne: SSE reconnect + resync.
- E2E: scenariusze z `99_pozostale.md` → „Scenariusze E2E”.

