# robot-controller — Specyfikacja komponentu (v0.8)

## 1. Rola w systemie (MUST)
`robot-controller` jest celowo prostym narzędziem dev/test:
- weryfikuje, że rozumiemy RoboCore/Robokit,
- potrafi sterować robotem i `robokit-sim` „tak jak Roboshop”,
- potrafi replayować sekwencje z `proxy-recorder` jako test integracyjny.

To jest komponent, który pozwala **odkleić ryzyko protokołu** od Core/Gateway.

## 2. Zakres i odpowiedzialności (normatywnie)
#### Dlaczego ten komponent istnieje
`robot-controller` jest celowo „płaski” i testowy: jego celem jest udowodnienie, że rozumiemy protokół RoboCore/Robokit i potrafimy sterować robotem identycznie jak Roboshop, a następnie przenieść tę wiedzę do Gateway.

#### Scope
- robot-controller łączy się bezpośrednio po TCP z robotem lub z robokit-sim.
- robot-controller potrafi wysłać minimalny zestaw komend (goTarget, stop, forkHeight) i odbierać statusy.
- robot-controller potrafi wczytać capture z proxy-recorder i odtwarzać sekwencje (replay) jako test integracyjny.

#### Responsibilities
robot-controller MUST:
- współdzielić bibliotekę framing/parsing z gateway (albo używać tego samego modułu),
- umożliwiać uruchomienie scenariuszy „smoke”: połącz, wyślij goTarget, potwierdź status, podnieś widły, zatrzymaj,
- generować logi na dysk (polecenia + odebrane ramki + timestamp),
- umożliwiać replay z capture (deterministycznie, na ile pozwala protokół).

robot-controller MUST NOT:
- zawierać logiki domeny (tasks/streams/locks) — to jest narzędzie.

Related: `10_*`, `15_*`, `17_*`.

## 3. Minimalny zestaw funkcji (MVP-dev)
robot-controller MUST umieć co najmniej:
- połączyć się po TCP na porty `TASK` + `CTRL` + `OTHER` (+ opcjonalnie `STATE`),
- wysłać:
  - `goTarget` (API 3051) z `{"id": "<LM/AP>"}`,
  - `stop` (API 2000),
  - `forkHeight` (API 6040) z `{"height": <meters>}`,
- odebrać statusy i potwierdzić:
  - ACK (`apiNo+10000`) oraz „DONE” przez telemetrię (na ile możliwe),
- logować na dysk wszystkie wysłane/odebrane ramki z timestampami.

## 4. Interfejs uruchomieniowy (AI-friendly) (MUST)
- `robot-controller smoke --robot-id ... --host ... --task-port ... --ctrl-port ... --other-port ...`
- `robot-controller replay --capture <sessionDir> [--speed 1.0]`

Kontrakt: wspiera `--config <json5>` i `--print-effective-config`.

## 5. Współdzielenie kodu (MUST)
- robot-controller MUST współdzielić framing/parsing z `adapters-robokit` (biblioteka),
  albo używać dokładnie tej samej implementacji nagłówka i parsera.

## 6. Testy (MUST)
- Unit: encode/decode framingu + payloady.
- Integration: smoke przeciwko `robokit-sim`.
- Golden: replay sesji z `proxy-recorder`.

