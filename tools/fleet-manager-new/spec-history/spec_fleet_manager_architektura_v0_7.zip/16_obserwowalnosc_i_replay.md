# Fleet Manager 2.0 — Obserwowalność i replay (v0.7)

Wymaganie nadrzędne: system MUST dać się odtworzyć po fakcie („co się stało?”) **z maksymalnie małą ilością domysłów**.

W praktyce oznacza to trzy klasy artefaktów:
1) **Core event log + snapshoty** (deterministyczny stan domeny),
2) **Capture integracyjne** (Gateway ↔ Robot, Proxy ↔ Roboshop/Robot),
3) **Golden traces** (artefakty testowe) + narzędzia replay.

---

## 1. Determinizm: co musi być eventem (MUST)

Event sourcing działa tylko, jeśli wszystkie „wejścia ze świata” które wpływają na stan domeny są zapisane jako eventy.

Fleet Core MUST:
- materializować jako eventy wszystkie informacje z integracji, które zmieniają stan domeny, np.:
  - `robotStateUpdated` (znormalizowany status robota),
  - `dependencyOffline/Online` (gateway/algo),
  - `commandDispatchResult` (ACK transportu),
  - `robotProtocolAck` (ACK robota, jeśli używane),
  - `sceneImported/Activated`,
  - `controlLeaseChanged`.

Zasada:
- **Replay domeny** jest deterministyczny.
- Integracje (roboty) są niedeterministyczne, więc ich wpływ na domenę MUSI przejść przez event log.

---

## 2. Event log (MUST: na dysk)

- Core MUST zapisywać wszystkie `EventEnvelope` do plików JSONL na dysk.
- Core MUST flushować po każdym evencie w MVP (`flushEveryEvent=true`).

Proponowana struktura:
```text
<dataDir>/
  events/
    events_000001.jsonl
    events_000002.jsonl
  snapshots/
    snapshot_000123456.json
    snapshot_000123999.json
```

Każdy wiersz `events_*.jsonl` to jeden `EventEnvelope`.

---

## 3. Snapshoty (MUST: na dysk)

Snapshot MUST zawierać:
- `schemaVersion`
- `contractsVersion`
- `cursor`
- `tsMs`
- pełny stan `/state` (albo stan kanoniczny)

Snapshoty MUST:
- być rotowane (`retentionCount`),
- być zapisywane co `intervalMs`,
- być tworzone przy zdarzeniach krytycznych (import/activate, provider switch, lease change),
- umożliwiać szybki restart Core.

Przykład:
```json5
{
  schemaVersion: "state-v0.6",
  contractsVersion: "contracts-v0.6",
  cursor: 123456,
  tsMs: 1736160000123,
  state: { /* jak GET /state */ }
}
```

---

## 4. Replay Core (MUST)

Core MUST mieć tryb uruchomienia:
- `--replay <dir>` lub `--dataDir <dir> --mode replay`

Tryb replay:
1) ładuje najnowszy snapshot,
2) odtwarza event log od `cursor+1`,
3) weryfikuje spójność (opcjonalnie):
   - monotoniczny cursor,
   - zgodność `contractsVersion`,
4) pozwala krokować ticki (MAY), ale tylko jeśli tick jest czysto deterministyczny.

Replay MUST być deterministyczny: ta sama sekwencja eventów + ta sama wersja kontraktów → ten sam stan.

---

## 5. Capture integracyjne (MUST/SHOULD)

### 5.1 Gateway capture (SHOULD w test/dev, MUST w debug)
- Gateway SHOULD zapisywać capture TCP:
  - raw bytes,
  - dekodowany header,
  - payload JSON (jeśli parsowalny),
  - korelację z `commandId` (jeśli dotyczy).
- Gateway MUST umożliwić włączenie/wyłączenie capture w configu.

### 5.2 Proxy/Recorder capture (MUST dla reverse engineeringu)
- Proxy/Recorder MUST zapisywać pełne raw bytes w dwie strony oraz metadane sesji.
- Format i layout sesji jest kanoniczny w `15_proxy_recorder.md`.

**Ważne:** Proxy capture jest źródłem prawdy do:
- golden traces parsowania RoboCore/Robokit,
- dokumentacji protokołu (`10_*`),
- budowy robokit-sim i robot-controller.

---

## 6. Golden traces (SHOULD)

„Golden trace” to artefakt testowy i debugowy, który pozwala odpalić testy regresji bez robota.

Minimalny golden trace:
```text
trace/
  README.md
  scene/...
  core/
    events.jsonl
    snapshots/...
  gateway/
    tcp_capture/...
  proxy/                       # jeśli dotyczy (np. RE protokołu)
    session.meta.json5
    tcp/.../conn_*_frames_*.jsonl
  expected.json5               # asercje
```

`expected.json5` zawiera asercje, np.:
```json5
{
  asserts: [
    { atCursor: 123900, expect: { robotId: "RB-01", navigationState: "blocked" } },
    { atCursor: 124010, expect: { lastCommandStatus: "completed" } },
  ]
}
```

---

## 7. Incident pack (SHOULD)

Każdy incydent integracyjny SHOULD kończyć się paczką:
- scena (scene package),
- event log + snapshoty,
- gateway capture (jeśli włączone),
- proxy session (jeśli dotyczy integracji z robotem/roboshop),
- minimalny opis „co robiliśmy” (w metadanych sesji proxy i/lub w README).

To jest podstawowy workflow debugowania i rozwoju z AI:
- AI dostaje paczkę,
- odtwarza replay,
- porównuje z expected,
- znajduje regresję.

