# Fleet Manager 2.0 — Strategia testów (v0.7)

Wymaganie: piramida testów + możliwość uruchamiania równolegle + golden assets.

---

## 1. Piramida testów (MUST)

1) **Unit tests** (najwięcej, najszybsze)
   - `contracts`: walidacje, serializacja/deserializacja, unknown field rejection,
   - `map-compiler`: parser `.smap`, konwersje jednostek, geometria (`DegenerateBezier`),
   - `fleet-core`: reducer/event-sourcing, Task Runner, Lease/Locks, snapshot writer,
   - `fleet-gateway`: framing RoboCore, resync, encode/decode, idempotencja, provider switch,
   - `proxy-recorder`: writer, rotacja plików, manifest/checksum, dekoder headerów (jeśli jest).

2) **Integration tests**
   - Core ↔ Gateway (HTTP) z mock providerem,
   - Gateway ↔ robokit-sim (TCP) dla goTarget/forkHeight/stop/push,
   - Core ↔ Algorithm Service (HTTP) (stub albo real),
   - robot-controller ↔ robokit-sim (TCP) (smoke protokołu),
   - proxy-recorder ↔ robokit-sim / robot-controller (MITM, capture → archive).

3) **E2E tests**
   - uruchom pełny stack: core + gateway + algo + robokit-sim (+ opcjonalnie ui headless),
   - odpal scenariusze z `18_scenariusze_e2e.md` (w tym Proxy/Controller).

---

## 2. Równoległość testów (MUST)

Testy MUST dać się uruchamiać równolegle (np. w CI). Zasady:

- każdy test używa osobnego `dataDir` (temp dir),
- porty są losowane lub przydzielane per suite,
- brak globalnych singletonów w procesie testów (albo izolacja przez worker),
- golden assets są tylko read-only.

---

## 3. Golden tests (SHOULD)

- Map Compiler: `graph.json` jako golden output.
- Gateway: golden TCP traces (z proxy-recorder).
- Core: replay golden eventlog+snapshot i porównanie `/state` z expected.
- Proxy/Recorder: golden sesja „mini” (krótka) + porównanie manifest checksum.

---

## 4. Testy odporności (SHOULD)

- symulacja przerw w sieci (drop TCP, timeouts),
- symulacja opóźnień i partial frames,
- testy idempotencji (powtarzanie dispatch komend),
- chaos tests w gateway: reconnect, resync po losowych bajtach.

---

## 5. Coverage i definicja „done” (MUST)

MVP jest „done”, jeśli:
- każdy endpoint ma testy pozytywne i negatywne,
- każdy kluczowy `ReasonCode` jest generowany w kontrolowanym teście,
- każdy scenariusz E2E przechodzi deterministycznie na robokit-sim,
- replay Core odtwarza stan bez różnic (bitowo w granicach kontraktu JSON).

---

## 6. Traceability matrix (SHOULD teraz, MUST przed produkcją)

Cel: połączyć wymagania normatywne z testami, tak żeby:
- człowiek widział „co jest pokryte”,
- AI mogła systematycznie domykać braki.

### 6.1 Minimalna macierz (MVP)
Tabela mapuje kluczowe MUST na testy/regresje (referencje do plików spec):

| Wymaganie | Gdzie w spec | Testy unit | Testy integration | E2E |
|---|---|---|---|---|
| Event log + snapshoty na dysk | `16_*`, `03_*`, `07_*`, `19_*` | core: writer/reducer | core: restart+replay | Scen. 1 |
| ControlLease + seize control | `07_*`, `08_*`, `03_*` | core: lease SM | core+api | Scen. 2 |
| Scene activation atomowo | `07_*`, `08_*` | core: activation SM | core+gateway stop best-effort | Scen. 6 |
| goTarget = LM/AP | `10_*`, `05_*`, `09_*` | gateway: encoder | gateway+sim | Scen. 3 |
| forkHeight (6040) | `10_*`, `05_*`, `09_*` | core: step runner | gateway+sim | Scen. 4 |
| Provider switch | `11_*`, `07_*`, `08_*`, `09_*` | core: policy | gateway: switch | Scen. 7 |
| Proxy capture + archive | `15_*`, `16_*`, `19_*` | proxy: manifest | proxy+controller | Scen. 0 |

### 6.2 Docelowo (post-MVP)
Docelowo SHOULD wprowadzić identyfikatory wymagań (np. `FM-CORE-ES-001`) i utrzymywać macierz w pliku
czytelnym dla ludzi i AI (np. JSON5), ale w MVP tabela powyżej wystarcza jako minimum.

