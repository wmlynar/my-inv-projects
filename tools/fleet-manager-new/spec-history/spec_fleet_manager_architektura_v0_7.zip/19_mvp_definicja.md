# Fleet Manager 2.0 — MVP (dokładna definicja + plan implementacji) (v0.7)

MVP ma być podstawą do:
- implementacji pierwszej wersji algorytmu,
- uruchomienia na `internalSim`,
- uruchomienia na `robokit-sim`,
- oraz bezpiecznego wejścia na realnego robota (etapowo, po potwierdzeniu protokołu).

**Kluczowa zmiana praktyczna:** zanim wejdziemy w Core/Gateway „na serio”, MUST mieć działające narzędzia
do podsłuchu i replay protokołu (`proxy-recorder`, `robot-controller`), bo to minimalizuje ryzyko integracyjne.

---

## 0. Addendum — uproszczenie MVP: Algorithm Level0 (walking skeleton)

### 0.1 Prompt użytkownika (wymaganie „meta” do planu MVP)

> bardzo wazney jest plan implementacji mvp  
> mam jeszcze taki pomysl na uproszczenie mvp:  
> pierwszy algorytm level0 to moze byc taki, ze po prostu wysyla robota bezposrednio komenda na pick i potem bezposrednio na drop  
> a robot sam znajduje trase.  
> to sie nadeje wylacznie gdy jest jeden robot, ale bedzie dobrym startem  
> potem algorytm trzeba podmienic na ten omawiany tutaj  
> ale mozna to robic dokladajac czesci stopniowo  
>  
> i w pierwszej wersji "wallking skeleton" zeby byl bardzo prosty algorytm (pollegajacy na routingu w robocie). bez zapewniania by braku kolizji

### 0.2 Intencja

To jest świadome „obniżenie poprzeczki” w pierwszym pionowym przekroju (walking skeleton), żeby:
- jak najszybciej uruchomić **E2E przepływ**: UI → Core → Gateway → robot/symulator (Robokit) → Core → UI,
- zminimalizować ryzyko, że utkwimy na zbyt wczesnym etapie na tematach multi-robot / rezerwacje korytarzy / deadlocki,
- mieć solidną bazę pod iteracyjne dokładanie kolejnych warstw algorytmu.

### 0.3 Definicja Algorithm Level0

Algorithm Level0 to tryb, w którym system **nie narzuca globalnej trasy** i **nie gwarantuje braku kolizji** (bo zakładamy pojedynczego robota).
Robot porusza się do celu używając **własnego routingu** (po stronie Robokit/Robocore).

Algorithm Level0 MUST spełniać:
- MUST działać tylko, gdy w scenie aktywny jest **jeden** robot (`maxActiveRobots=1`); jeśli wykryje >1, MUST zwrócić `hold=true` dla pozostałych.
- MUST *nie* używać rezerwacji korytarzy: `locksRequested` MUST być puste.
- MUST opierać nawigację wyłącznie o `NodeRef` (`LocationMark` albo `ActionPoint`) – bez `(x,y)`.

Algorithm Level0 SHOULD:
- generować minimalnie zrozumiały plan kroków (TaskStep) typu:
  - `moveTo` → `goTarget` na `LocationMark/ActionPoint`,
  - `forkHeight` → `forkHeight(heightM)` zgodnie z parametrami ActionPoint / worksite.
- po wykonaniu taska (pick→drop) wysłać robota na park (`ParkPoint`/`LocationMark`) jeśli brak kolejnych zadań.

Algorithm Level0 MUST NOT:
- implementować unikania kolizji między robotami (to jest świadomie poza Level0),
- próbować „rolling target” w sensie *wymuszania* globalnej ścieżki; w Level0 target jest po prostu celem (final target) kroku.

### 0.4 Wymagania po stronie Core/Gateway dla Level0

Core MUST umożliwić uruchomienie MVP bez warstwy traffic management:
- MUST mieć tryb runtime `trafficMode=NONE` (albo równoważny), który:
  - nie wymaga locków od algorytmu,
  - nie blokuje dispatchu komend ruchem po grafie.
- MUST zachować pełny audyt (log na dysk + snapshoty) jak dla docelowego algorytmu.

Gateway MUST:
- obsługiwać `goTarget` (API 3051) oraz `forkHeight` (6040) jako minimalny zestaw do wykonania „pick→drop” na ActionPoint.

### 0.5 Kryterium ukończenia Level0 (exit criteria)

Level0 uznajemy za gotowe, jeśli dla `robokit-sim` (a docelowo real robota):
- UI tworzy Task (PICK→DROP) lub importuje go ze streamu,
- algorytm przypisuje task do jedynego aktywnego robota,
- robot dojeżdża do pick i drop (routing w robocie),
- wykonywana jest akcja wideł (`forkHeight`) na ActionPoint,
- całość jest odtwarzalna z logów (replay) i ma deterministyczne snapshoty stanu.

Następny krok po Level0: włączenie docelowego algorytmu rezerwacji korytarzy (Level1/Level2) i przejście na multi-robot.

---

## 1. MUST w MVP (produktowe minimum)

### 1.1 Fleet Core (source of truth)
Core MUST dostarczyć:
- Import sceny (katalog lub zip) + walidacja.
- Activate sceny (procedura atomowa) + jawna semantyka „co się dzieje przy przełączeniu”.
- `GET /state` snapshot + `GET /events` SSE (EventEnvelope).
- ControlLease (seize/renew/release + seize control wywłaszcza poprzedniego).
- Event log + snapshoty **na dysk** (wymóg bezdyskusyjny).
- Manual commands (MVP): `stop`, `goTarget`.
- Minimalny Task Runner: `pickDrop` + kroki `moveTo` i `forkHeight`.
- Integracja z Algorithm Service (HTTP): `POST /algo/v1/decide` (w MVP algo może być stubem, ale port i kontrakt muszą istnieć).

### 1.2 Fleet Gateway (adapter do robotów)
Gateway MUST dostarczyć:
- Provider: `internalSim` + `robokitSim` + `robocore` (ten sam protokół TCP).
- Obsługa framingu RoboCore/Robokit (robust parser + resync + partial frames).
- Minimalne komendy TCP:
  - 3051 `goTarget` (rolling target: LM/AP),
  - 2000 `stop`,
  - 6040 `forkHeight`,
  - 6041 `forkStop`.
- Minimalny status:
  - 1004 `robot_status_loc_req` (pozycja),
  - (opcjonalnie) push 9300/19301.
- Idempotencja dla `commandId` + limity inflight + cooldown po reconnect (anti command-storm).
- Hot-switch providera per robot.

### 1.3 Algorithm Service (port decyzyjny)
Algorithm Service MUST dostarczyć:
- `/health`
- `/algo/v1/decide`
- deterministyczny stub (np. zawsze hold) albo minimalną logikę,
- testy deterministyczności na golden input/output.

### 1.4 UI (operator)
UI MUST dostarczyć:
- read-only dashboard: mapa + roboty + tasks + worksites + streams,
- kontrola: seize/release + manual stop + manual goTarget,
- natychmiastowy read-only po utracie lease,
- odporność na reconnect SSE (odtwarzanie od cursor).

### 1.5 Map Compiler
Map Compiler MUST dostarczyć:
- `.smap` → `graph.json` (nodes, edges, `DegenerateBezier`, `propsCompiled.lengthM`),
- deterministyczność + walidacje,
- golden testy (wejście `.smap` → oczekiwane `graph.json`).

---

## 2. MUST w MVP-dev (narzędzia, które odblokowują integrację)

Te elementy nie są „featurem dla operatora”, ale są krytyczne, żeby w ogóle bezpiecznie wejść w robota.

### 2.1 Proxy/Recorder (proxy-recorder)
Proxy/Recorder MUST:
- uruchamiać się z CLI + config (promptable),
- logować raw bytes w dwie strony,
- mieć layout logów poza repo,
- ostrzegać o dużych logach,
- umożliwiać archiwizację + manifest z checksumami.

Spec: `15_proxy_recorder.md`.

### 2.2 Robot controller (robot-controller)
robot-controller MUST:
- potrafić wykonać smoke test protokołu (goTarget/stop/forkHeight),
- potrafić działać przeciwko robokit-sim i przeciwko real robot (w bezpiecznych warunkach),
- logować na dysk sekwencje komend i statusów,
- umieć replay z capture (co najmniej w trybie offline test harness).

---

## 3. SHOULD w MVP (silnie zalecane)
- SSE filter `types=`.
- `/state?view=uiMinimal`.
- Gateway capture w debug.
- Golden trace pipeline (z proxy/gateway/core).

---

## 4. Poza MVP (explicit)
- Security (authN/authZ/TLS/RBAC)
- Multi-instance Core / HA
- Automatyczne ładowanie mapy do robota (Roboshop sync)
- Zaawansowane obstacle avoidance (lokalne planowanie + „width>0”)
- Rozbudowane UI (edycja sceny w UI)

---

## 5. Plan implementacji MVP (komponentami, w kolejności minimalizującej ryzyko)

Ta kolejność jest celowa: najszybciej budujemy pętlę feedbacku i redukujemy ryzyko integracyjne.

### Faza 0 — Golden assets i katalogowanie sesji (MUST)
- Skatalogować istniejące logi/sesje (z proxy) jako „golden set”:
  - nazwy sesji,
  - do czego służą,
  - checksumy,
  - minimalny README per sesja.

### Faza 1 — Proxy/Recorder (pierwsze!)
Deliverables:
- CLI + config + presety robokit-all,
- layout logów w `~/robokit_logs/...`,
- raw bytes w obie strony,
- warning o rozmiarze,
- archiwizacja + manifest.

Testy:
- unit (writer/rotacja/manifest),
- integration (proxy up → połączenie → zapis → archive → checksum).

### Faza 2 — Robot-controller (smoke test protokołu)
Deliverables:
- connect + goTarget(LM/AP) + stop + forkHeight,
- logowanie na dysk (komendy + statusy),
- replay sekwencji z capture.

Testy:
- przeciwko robokit-sim,
- opcjonalnie przeciwko real robot (kontrolowane warunki).

### Faza 3 — Robokit-sim (albo dopięcie istniejącego)
Deliverables:
- minimalne API: status + goTarget + forkHeight + stop + push (zgodnie z `10_*`),
- tryb „scripted replay” (odtwarzanie statusów z logów) — bardzo pomocne,
- (opcjonalnie) prosta fizyka.

### Faza 4 — Fleet-gateway (HTTP + TCP)
Deliverables:
- `/gateway/v1` komendy z idempotencją,
- provider switching,
- reconnect/retry/circuit breaker,
- capture debug na dysk.

Testy:
- golden TCP traces,
- chaos tests (dropy, partial frames).

### Faza 5 — Fleet-core (event sourcing + API)
Deliverables:
- event log + snapshoty na dysk,
- import + activate sceny,
- `/state` + SSE,
- ControlLease,
- manual commands,
- minimal Task Runner + integracja z algo stub.

Testy:
- deterministyczny replay,
- scenariusze E2E.

### Faza 6 — Algorithm-service (Level0 → docelowy)
Deliverables:
- `/algo/v1/decide` z kontraktami (patrz: `06_port_algorytmu_i_api_algorytmu.md`),
- deterministyczne testy (golden I/O; równoległe w CI),
- przełączalny tryb algorytmu (konfiguracyjnie, bez negocjacji w runtime):
  - `level0` — **walking skeleton**: pojedynczy robot, brak locków, routing po stronie robota,
  - `level1+` — docelowy algorytm rezerwacji korytarzy (osobna spec algorytmu).

### Faza 6A — Algorithm Level0 (pierwszy pionowy przekrój)
W tej podfazie celem jest „działa end-to-end”, nie „jest optymalnie”.
Deliverables:
- algorytm przypisuje taski tylko do jedynego aktywnego robota,
- brak `locksRequested`,
- task wykonuje się jako sekwencja kroków `moveTo`/`forkHeight` (albo równoważna),
- retry/timeouty kroków są jawne i logowane.

### Faza 6B — Upgrade do docelowego algorytmu
Deliverables:
- włączenie locków i rolling target,
- wsparcie wielu robotów,
- regresja na golden sesjach (replay).

## Faza 7 — UI-frontend
Deliverables:
- read-only + lease + manual,
- debug widoki (reason codes, current command, rolling target).

---

## 6. Kryteria akceptacji MVP (MUST)
- Wszystkie scenariusze z `18_scenariusze_e2e.md` przechodzą na robokit-sim.
- Event log + snapshot pozwalają odtworzyć stan po awarii.
- Przerwy w komunikacji nie powodują „pętli komend” (command storm) i nie gubią audytu.
- Proxy/Recorder potrafi w powtarzalny sposób zebrać sesję i ją zarchiwizować.

---

## 7. Blokujące niejednoznaczności (MUST rozstrzygnąć przez capture / RE)

1) **RoboCore/Robokit: reason codes blokad i obstacle avoidance** (kiedy i jak robot zgłasza, że chce omijać).  
2) **ACK vs DONE**: doprecyzować, które ramki są ack (seq/apiNo) oraz które statusy oznaczają zakończenie.  
3) **Sensory (laser) — capture**: zebrać i skatalogować sesję z danymi sensorów (post-MVP algorytm), ale dane zbieramy już teraz.  
4) **Porty i warianty protokołu**: potwierdzić na real robocie (proxy + robot-controller).

Szczegóły RE i checklista: `10_protokol_robocore_robokit.md`.

