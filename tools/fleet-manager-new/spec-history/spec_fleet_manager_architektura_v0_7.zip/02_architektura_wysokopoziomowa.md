# Fleet Manager 2.0 — Architektura wysokopoziomowa (v0.7)

## 1. Cel systemu (MUST)
Fleet Manager steruje flotą autonomicznych wózków widłowych w obrębie **jednej aktywnej sceny** (mapa + konfiguracja), minimalizując ryzyko kolizji i przestojów, przy założeniu, że robot ma własny lokalny planner i może lokalnie omijać przeszkody (docelowo).

W MVP Fleet Manager:
- MUST działać bez frontendu (headless),
- MUST wspierać wiele frontendów równolegle (obserwacja), z wyłącznością sterowania (Control Lease / seize control),
- MUST wspierać symulację wielu robotów (wewnętrzną),
- MUST pozwalać przełączać pojedynczego robota między providerami (internalSim ↔ robokit-sim ↔ real robot),
- MUST wspierać dynamiczną zmianę sceny (import + activation),
- MUST zapewniać pełny audyt/replay: event log + snapshoty na dysk.

## 2. Zasady architektury (MUST)

### 2.1 Domena oddzielona od integracji
- **Fleet Core** = domena + deterministyczna logika + publiczne API + persystencja.
- **Integracje** (roboty, Roboshop, proxy, parsing ramek TCP) są poza domeną i mają cienkie adaptery.

Konsekwencje (MUST):
- Core MUST działać bez UI i bez realnych robotów (np. tylko symulacja / stuby gateway).
- Core MUST być testowalny z mockami gateway i algorytmu.
- Gateway MUST być wymienialny bez zmiany logiki domenowej.

### 2.2 Single-writer w MVP
- Core jest single-writer w MVP (jedna instancja modyfikująca stan).
- Wszystkie mutacje stanu Core MUST przechodzić przez event log.
- Replay MUST odtwarzać identyczny stan dla identycznego event log + tej samej wersji kontraktów.

### 2.3 Wewnątrz systemu: HTTP
- Interfejsy między usługami wewnątrz systemu MUST używać HTTP (REST) + SSE (dla strumienia zdarzeń).
- Wyjątki: zewnętrzne protokoły robotów (RoboCore/Robokit) są TCP i są obsługiwane WYŁĄCZNIE przez warstwę integracji.

## 3. Kanoniczny obraz systemu (diagramy)

### 3.1 Diagram kontekstowy (C4-ish)
```mermaid
flowchart LR
  operator[Operator / UI user] -->|HTTP+SSE| ui[ui-frontend]
  ui -->|HTTP+SSE /api/v1| core[fleet-core]
  core -->|HTTP /algo/v1| algo[algorithm-service]
  core -->|HTTP /gateway/v1| gw[fleet-gateway]
  gw -->|TCP RoboCore/Robokit| robots[Roboty fizyczne]
  gw -->|TCP RoboCore/Robokit| sim[robokit-sim]

  roboshop[Roboshop / RDS] -->|HTTP| bridge[roboshop-bridge]
  bridge -->|uruchamia/wywołuje| compiler[map-compiler]
  bridge -->|import scene (HTTP)| core

  proxy[proxy-recorder] -. podsłuch TCP/HTTP .- robots
  proxy -. podsłuch TCP/HTTP .- roboshop
  proxy -. capture .- sim

  controller[robot-controller (dev/test)] -->|TCP RoboCore/Robokit| robots
  controller -->|TCP RoboCore/Robokit| sim
  controller -->|czyta capture| proxy
```

### 3.2 Diagram kontenerów i interfejsów (MVP)
```mermaid
flowchart TB
  subgraph Clients
    ui[ui-frontend]
    cli[CLI / test harness]
  end

  subgraph Domain
    core[fleet-core\n/api/v1\nSSE /api/v1/events/stream\nevent log + snapshots]
    algo[algorithm-service\n/algo/v1]
  end

  subgraph Integration
    gw[fleet-gateway\n/gateway/v1\nprovider switching]
    bridge[roboshop-bridge]
    compiler[map-compiler]
  end

  subgraph DevTools
    proxy[proxy-recorder]
    controller[robot-controller]
  end

  subgraph External
    robots[Roboty (RoboCore/Robokit TCP)]
    sim[robokit-sim (TCP)]
    roboshop[Roboshop/RDS (HTTP)]
  end

  ui -->|HTTP+SSE| core
  cli -->|HTTP| core
  core -->|HTTP| algo
  core -->|HTTP| gw
  gw -->|TCP| robots
  gw -->|TCP| sim
  bridge -->|HTTP| roboshop
  bridge -->|exec/CLI or HTTP| compiler
  bridge -->|HTTP import| core
  proxy -. intercept .- robots
  proxy -. intercept .- roboshop
  controller -->|TCP| robots
  controller -->|TCP| sim
```

### 3.3 Sekwencja: tick loop (Core → Algo → Core → Gateway → Robot)
```mermaid
sequenceDiagram
  autonumber
  participant UI as ui-frontend
  participant Core as fleet-core
  participant Algo as algorithm-service
  participant GW as fleet-gateway
  participant R as Robot/Sim (RoboCore)

  Note over Core: tickHz (np. 10Hz)\nstan = event log + snapshot
  Core->>GW: GET /gateway/v1/robots/status?since=...
  GW-->>Core: RobotStatus[] (znormalizowane)

  Core->>Algo: POST /algo/v1/decide (AlgorithmInputSnapshot)
  Algo-->>Core: AlgorithmDecision (np. setRollingTarget)

  Note over Core: mapowanie setRollingTarget -> CommandRecord.goTarget\n+ dedup + rate-limit
  Core->>Core: append EventEnvelope(s) + snapshot (na dysk)
  Core->>GW: POST /gateway/v1/robots/{id}/commands (CommandRecord)
  GW->>R: TCP frame goTarget / forkHeight
  R-->>GW: TCP ack/status frames
  GW-->>Core: 200 ACK + status telemetry

  Core-->>UI: SSE EventEnvelope (delta)\n+ opcjonalnie stateSnapshot
```

### 3.4 Sekwencja: import i aktywacja sceny
```mermaid
sequenceDiagram
  autonumber
  participant UI as ui-frontend
  participant Core as fleet-core
  participant GW as fleet-gateway

  UI->>Core: POST /api/v1/scenes/import (zip/folder)
  Core->>Core: walidacja + zapis paczki sceny na dysk
  Core-->>UI: 202 {importId}
  UI->>Core: POST /api/v1/scenes/{sceneId}/activate
  Core->>Core: enter activation state\n(pause + stop/cancel)
  Core->>GW: POST /gateway/v1/robots/{id}/commands (stop/cancel)
  GW-->>Core: ACK
  Core->>Core: reset locks/tasks per policy\nload new scene\nappend events + snapshots
  Core-->>UI: SSE sceneActivated + stateSnapshot
```

### 3.5 Sekwencja: hot-switch providera robota (sym ↔ robokit-sim ↔ real)
```mermaid
sequenceDiagram
  autonumber
  participant UI as ui-frontend
  participant Core as fleet-core
  participant GW as fleet-gateway

  UI->>Core: POST /api/v1/robots/{id}/provider:switch {targetProvider}
  Core->>Core: acquire per-robot switch lock\nhold robot\nappend events
  Core->>GW: POST /gateway/v1/providers/switch {robotId,targetProvider}
  GW->>GW: close old connection\nopen new\nhandshake/resync
  GW-->>Core: {status: switched|failed, details}
  Core->>Core: if switched => require resync tick\nrelease hold (policy)
  Core-->>UI: SSE providerSwitched + RobotRuntimeState
```

## 4. Specyfikacje komponentów (normatywnie)

> Cel tej sekcji: przywrócić „warstwę, która zniknęła” w v0.4 — opis odpowiedzialności, wewnętrznych modułów, przepływów i failure modes dla każdego komponentu, bez dodawania nowych plików.

Wzorzec opisu komponentu:
- Scope (co jest w środku / poza),
- Responsibilities (MUST/MUST NOT),
- Interfaces (co wystawia / co konsumuje),
- State & persistence (source of truth),
- Runtime model (pętle, kolejki, deterministyczność),
- Failure modes + odporność,
- Observability (logi/eventy/snapshoty),
- Testy (minimum).

### 4.1 fleet-core (domena + publiczne API)

#### Scope
Fleet Core jest źródłem prawdy dla stanu systemu: aktywnej sceny, stanu robotów (znormalizowanego), tasks/streams/worksites, locków/rezerwacji, komend oraz lease kontroli.

#### Responsibilities
Fleet Core MUST:
- być **source of truth** dla stanu domeny (scene + runtime),
- udostępniać publiczne API `/api/v1/**` oraz SSE `/api/v1/events/stream`,
- walidować wszystkie mutacje (scena, tasks, manual commands) i zwracać spójne `ErrorEnvelope`,
- utrzymywać **event log na dysku** oraz **snapshoty na dysku** i umożliwiać replay po restarcie,
- wykonywać tick loop w stałym rytmie (`tickHz`) i domyślnie działać deterministycznie,
- integrować algorytm przez HTTP (`/algo/v1/decide`) oraz mapować decyzje algorytmu na `CommandRecord`,
- pełnić rolę dispatchera: wysyłać komendy do `fleet-gateway` oraz kontrolować idempotencję i deduplikację,
- egzekwować **Control Lease** (seize/renew/release): jedna instancja operatora ma kontrolę naraz,
- w trybie awaryjnym MUST przejść do fail-safe (hold/stop) zgodnie z polityką w `07_*`.

Fleet Core MUST NOT:
- implementować parsowania ramek RoboCore/Robokit TCP,
- łączyć się bezpośrednio z robotami po TCP,
- zawierać importu Roboshop jako „core feature” (to jest bridge/tooling).

Fleet Core SHOULD:
- aktywować scenę w stanie `paused/hold` (bezpieczniej w MVP),
- mieć jawny budżet ticka i ograniczać pracę w ticku (np. algorytm timeout + fallback).

#### Interfaces
Wystawia (public):
- `/api/v1/*` — patrz `08_api_fleet_core.md`.

Konsumuje (private):
- `algorithm-service` — `POST /algo/v1/decide`.
- `fleet-gateway` — `POST /gateway/v1/...` + `GET /gateway/v1/...`.

#### State & persistence
- Event log MUST być zapisywany na dysk w formacie append-only (np. JSONL).
- Snapshot MUST być zapisywany na dysk okresowo oraz przy zdarzeniach krytycznych (import/activate, provider switch, zmiana lease).
- Snapshot MUST zawierać `schemaVersion` i `contractsVersion`.

#### Runtime model
- Tick loop MUST być single-threaded względem mutacji domeny (unikamy race conditions).
- IO do Gateway/Algo MUST mieć timeouty; wyniki IO MUSZĄ być materializowane jako eventy.
- Mapowanie `AlgorithmDecision` → `CommandRecord` jest kanoniczne:
  - `setRollingTarget(targetRef)` → `CommandRecord.type="goTarget"` z `payload.targetRef`.
  - Core MUST deduplikować identyczny rolling target oraz stosować rate-limit (`rollingTarget.updateMinIntervalMs`).
  - Core MUST tworzyć `CommandRecord` przed dispatch (event first).

#### Failure modes i odporność
- Jeśli algorytm timeout/error: Core MUST wejść w `hold` dla robotów i emitować `systemError` (`causeCode=ALGO_TIMEOUT|ALGO_ERROR`).
- Jeśli gateway offline: Core MUST oznaczyć robota jako `offline` i MUST wstrzymać dispatch do tego robota.
- Jeśli telemetria starsza niż `statusAgeMaxMs`: Core MUST oznaczyć robota jako `blocked.isBlocked=true` z reason code.

#### Observability
- Core MUST logować: eventy wejściowe, eventy domenowe, snapshoty, a w trybie debug także request/response algorytmu.
- Core MUST emitować eventy lease i activation (patrz `03_*` i `07_*`).

#### Testy
- Core MUST mieć piramidę testów (unit → integration → e2e), a testy MUST być możliwe do uruchomienia równolegle.
- Core MUST mieć „golden traces” (event log + snapshoty) do regresji replay.

Related: `03_*`, `05_*`, `07_*`, `08_*`, `16_*`, `17_*`.

### 4.2 algorithm-service (czysta logika decyzyjna)

#### Scope
Algorithm Service jest niezależnym komponentem decyzyjnym: otrzymuje snapshoty i zwraca decyzje, bez własnej persystencji domenowej.

#### Responsibilities
Algorithm Service MUST:
- być deterministyczny dla danego wejścia,
- być side-effect free (brak IO do świata zewnętrznego jako część decyzji),
- zwracać odpowiedź w czasie < `algorithm.timeoutMs`,
- zwracać komendy w postaci `AlgorithmRobotCommand` (np. `setRollingTarget`, `hold`) oraz ewentualnie `locksRequested`.
- MUST wspierać co najmniej dwa profile działania (konfiguracyjnie):
  - `level0` (walking skeleton): pojedynczy robot, `locksRequested=[]`, target jako finalny `NodeRef` (routing w robocie),
  - `level1+` (docelowy): multi-robot + locki/rolling target wg specyfikacji algorytmu.

Algorithm Service MUST NOT:
- modyfikować stanu Core bezpośrednio,
- wykonywać komunikacji z robotem/gateway.

#### Interfaces
- `POST /algo/v1/decide` (snapshot → decision): `06_port_algorytmu_i_api_algorytmu.md`.

#### Failure modes
- W razie przeciążenia, service SHOULD zwrócić 503 (Core wejdzie w hold).

#### Testy
- MUST mieć testy deterministyczności (ten sam input → ten sam output) + golden snapshots.

Related: `06_*`, `17_*`, `18_*`.

### 4.3 fleet-gateway (integracja robotów i provider switching)

#### Scope
Fleet Gateway jest adapterem do robotów: tłumaczy `CommandRecord` i kontrakty statusów na protokoły zewnętrzne (RoboCore/Robokit). Gateway ukrywa TCP, reconnecty i normalizuje telemetrię.

#### Responsibilities
Fleet Gateway MUST:
- udostępniać API `/gateway/v1/**` dla Fleet Core (UI nie komunikuje się z Gateway),
- implementować providery: `internalSim`, `robokitSim`, `robocore` (real),
- wspierać hot-switch providera per robot (procedura w `11_*`),
- deduplikować komendy po `commandId` i zapewniać idempotentne ACK,
- normalizować statusy robota do `RobotRuntimeState.navigation/blocked/fork` (kanoniczny model),
- implementować timeouts/retry/backoff + circuit breaker na TCP,
- parsować ramki TCP odporne na partial frames i resync (patrz `10_*`),
- umożliwić debug capture (MAY) oraz integrację z proxy-recorder (dev).

Fleet Gateway MUST NOT:
- przyjmować mutacji od UI,
- implementować logiki przydziału zadań/lockowania (to domena/algorytm).

#### Interfaces
Wystawia (private): `09_api_fleet_gateway.md`.

Konsumuje (external): RoboCore/Robokit TCP — `10_protokol_robocore_robokit.md`.

#### Ważna zasada: mapowanie NodeId → external station id
- Fleet Core SHOULD rozwiązywać `targetRef.nodeId` do identyfikatora zewnętrznego (`targetExternalId`) na podstawie `SceneGraph.nodes[].externalRefs`.
- Gateway MUST preferować `payload.targetExternalId` jeśli jest podane.
- Jeśli `targetExternalId` brak, Gateway MAY użyć `targetRef.nodeId` jako fallback (przy założeniu, że NodeId = stationId).

#### Failure modes i odporność
- Gateway MUST raportować `connected/connecting/disconnected/error` per robot oraz `lastSeenTsMs`.
- Jeśli robot w emergency: Gateway MUST odmówić wysłania komend ruchu (failsafe) i zwrócić błąd z reason code.

#### Testy
- MUST mieć golden captures dla parsowania ramek i generowania ramek (z proxy-recorder).

Related: `09_*`, `10_*`, `11_*`, `15_*`, `17_*`.

### 4.4 ui-frontend (wizualizacja i sterowanie operatora)

#### Scope
UI jest klientem: renderuje mapę, roboty, worksites/streams/tasks, umożliwia przejęcie kontroli (lease) i wykonywanie mutacji przez Core.

#### Responsibilities
UI MUST:
- łączyć się tylko z Fleet Core (nigdy bezpośrednio z Gateway),
- subskrybować SSE i budować lokalny stan jako funkcję `stateSnapshot + delty`,
- obsługiwać Control Lease:
  - pokazywać kto ma kontrolę,
  - umożliwiać `seize`, `renew`, `release`,
  - w trybie viewer nie wykonywać mutacji,
- być odporne na reconnect SSE (wznawianie od `cursor`).

UI MUST implementować mechanizm „seize control”:
- instancja UI, która wykonuje `seize`, wywłaszcza poprzedniego operatora;
- UI MUST traktować utratę lease jako natychmiastowe przejście w read-only.

UI SHOULD:
- mieć czytelne debug widoki: locki, trasy, rolling target, bieżące komendy, reason codes.

Related: `03_*`, `07_*`, `08_*`.

### 4.5 roboshop-bridge (import/kompatybilność z Roboshop/RDS)

#### Scope
Bridge jest opcjonalnym komponentem integracyjnym: pobiera mapy/konfiguracje z Roboshop/RDS i generuje paczki sceny dla Core.

Roboshop Bridge MUST:
- mapować formaty Roboshop/RDS na kanoniczny Scene Package (`04_*`),
- dokumentować mapowanie ID (Roboshop ↔ SceneGraph nodeIds/externalRefs),
- umożliwiać import scen do Fleet Core (HTTP lub przez export paczki).

Related: `13_*`, `14_*`.

### 4.6 map-compiler (kompilacja mapy: .smap → graph.json)

#### Scope
Map Compiler jest narzędziem deterministycznym: bierze `.smap` i produkuje kanoniczny `SceneGraph` w `graph.json`.

Map Compiler MUST:
- zachować geometrię źródłową (dla `DegenerateBezier`) i przeliczyć ją do metrów,
- wyliczyć `lengthM` deterministycznie,
- (SHOULD) wygenerować `geometrySamples` dla łatwej symulacji i wizualizacji,
- dostarczyć testy regresji (golden files) dla map.

Related: `04_*`, `14_*`, `17_*`.

### 4.7 proxy-recorder (dev tool: podsłuch + capture)

#### Scope
Proxy/Recorder jest niezależnym narzędziem developerskim do podsłuchu ruchu TCP (RoboCore) i HTTP (Roboshop/RDS), z zapisem na dysk.

Proxy/Recorder MUST:
- być transparentnym proxy (nie modyfikuje payloadów),
- mieć konfigurowalne porty i upstreamy,
- zapisywać capture na dysk w formacie nadającym się do replay/regresji (np. JSONL + hex dump + timestamp),
- oznaczać capture metadanymi (robotId/addr/port/time).

Related: `15_*`, `10_*`.

### 4.8 robokit-sim (zewnętrzny symulator)

#### Scope
Robokit-sim jest zewnętrznym symulatorem udającym RoboCore/Robokit TCP. Jest używany do testów integracyjnych bez fizycznego robota.

Zasady:
- Gateway MUST móc przełączyć robota na robokit-sim bez zmiany logiki Core/Algo.
- Scenariusze E2E SHOULD pokrywać: internalSim (czysto), robokit-sim (protokół), real robot (docelowo).

Related: `11_*`, `18_*`.

### 4.9 robot-controller (dev/test: weryfikacja protokołu)

#### Dlaczego ten komponent istnieje
`robot-controller` jest celowo „płaski” i testowy: jego celem jest udowodnienie, że rozumiemy protokół RoboCore/Robokit i potrafimy sterować robotem identycznie jak Roboshop, a następnie przenieść tę wiedzę do Gateway.

#### Scope
- robot-controller łączy się bezpośrednio po TCP z robotem lub z robokit-sim.
- robot-controller potrafi wysłać minimalny zestaw komend (goTarget, stop, forkHeight) i odbierać statusy.
- robot-controller potrafi wczytać capture z proxy-recorder i odtwarzać sekwencje (replay) jako test integracyjny.

#### Responsibilities
robot-controller MUST:
- współdzielić bibliotekę framing/parsing z gateway (albo używać tego samego modułu),
- umożliwiać uruchomienie scenariuszy „smoke”: połącz, wyślij goTarget, potwierdź status, podnieś widły, zatrzymaj,
- generować logi na dysk (polecenia + odebrane ramki + timestamp),
- umożliwiać replay z capture (deterministycznie, na ile pozwala protokół).

robot-controller MUST NOT:
- zawierać logiki domeny (tasks/streams/locks) — to jest narzędzie.

Related: `10_*`, `15_*`, `17_*`.

## 5. Co jest „MVP-tylko” vs „post-MVP” (krótko)
Pełne MVP: `19_mvp_definicja.md`.

W skrócie (MVP):
- Core + Gateway + Algo + UI (viewer+lease) + internalSim + replay/log/snapshot.
- Roboshop Bridge / proxy-recorder / robot-controller są narzędziami wspierającymi development, ale ich minimalne wersje są bardzo pomocne od początku.

Post-MVP (w tym pliku tylko jako kontekst):
- security, HA, dwukierunkowa synchronizacja z Roboshop, advanced obstacle avoidance.


## 5. Runbook (MVP) — uruchamianie komponentów (AI-friendly)

Cel: żeby można było wprost mówić do AI/Codexa: „uruchom komponent X z configiem Y”, bez interpretacji.

### 5.1 Kontrakt uruchomieniowy usług (MUST)
Każdy komponent uruchamiany jako proces (`fleet-core`, `fleet-gateway`, `algorithm-service`) MUST:
- wspierać flagę `--config <path>` (JSON5),
- wspierać `--print-effective-config` (drukuje wynik merge: defaults + config + env),
- wspierać `--log-level <level>` (np. debug|info|warn|error),
- logować na starcie:
  - effective config,
  - port/host,
  - dataDir,
  - wersję kontraktów (`contractsVersion`).

Jeśli dany komponent ma persystencję, MUST wspierać `--data-dir <path>`.

### 5.2 fleet-core — uruchomienie (MVP)
Kontrakt:
- słucha na `http://0.0.0.0:<corePort>/api/v1`
- trzyma dane w `dataDir` (events+snapshots) na dysku

Przykład:
```bash
fleet-core \
  --config ./configs/fleet-core.local.json5 \
  --data-dir ./var/core \
  --print-effective-config
```

### 5.3 fleet-gateway — uruchomienie (MVP)
Kontrakt:
- słucha na `http://0.0.0.0:<gatewayPort>/gateway/v1`
- ma skonfigurowane roboty i providery (internalSim/robokitSim/robocore)
- (debug) ma `captureDir` na dysk

Przykład:
```bash
fleet-gateway \
  --config ./configs/fleet-gateway.local.json5 \
  --print-effective-config
```

### 5.4 algorithm-service — uruchomienie (MVP)
Kontrakt:
- słucha na `http://0.0.0.0:<algoPort>/algo/v1`
- jest side-effect free (bez pisania do core)

Przykład:
```bash
algorithm-service --config ./configs/algo.local.json5 --print-effective-config
```

### 5.5 ui-frontend — uruchomienie (MVP)
UI to web app; MUST dać się skonfigurować przez:
- `CORE_BASE_URL` (np. `http://localhost:8080/api/v1`)
- `SSE_URL` (np. `http://localhost:8080/api/v1/events`)

Przykład:
```bash
ui-frontend --core-url http://localhost:8080/api/v1
```

### 5.6 proxy-recorder — uruchomienie (MVP-dev)
Patrz kanoniczna specyfikacja: `15_proxy_recorder.md`.

### 5.7 robot-controller — uruchomienie (MVP-dev)
Kontrakt:
- potrafi łączyć się do robota/sima (direct lub przez proxy),
- potrafi wykonać smoke sekwencję,
- loguje na dysk.

Przykład:
```bash
robot-controller smoke \
  --robot-id RB-01 \
  --host 127.0.0.1 \
  --task-port 29206 \
  --other-port 29210 \
  --ctrl-port 29205
```

### 5.8 full stack lokalnie (SHOULD)
Minimalnie:
1) uruchom `robokit-sim` (jeśli używane),
2) uruchom `fleet-gateway`,
3) uruchom `algorithm-service`,
4) uruchom `fleet-core`,
5) uruchom `ui-frontend` (opcjonalnie).

W CI rekomendowane jest `docker compose` (post-MVP dopracujemy), ale kontrakt uruchomieniowy MUST pozostać stabilny.

