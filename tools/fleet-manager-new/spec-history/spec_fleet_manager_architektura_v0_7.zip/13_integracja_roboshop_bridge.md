# Fleet Manager 2.0 — Integracja: Roboshop Bridge (v0.7)

Roboshop jest zewnętrzną aplikacją do mapowania i konfiguracji.
W architekturze Fleet Managera Roboshop Bridge jest osobnym komponentem (czytelność granic).

## 1. Rola Roboshop Bridge (MUST)
- Bridge MUST pobierać/odbierać mapę i konfiguracje z Roboshop.
- Bridge MUST transformować je do Scene Package (manifest + raw.smap + config/*.json5).
- Bridge MUST wywołać import sceny do Fleet Core.

## 2. Interfejsy
W MVP zakładamy prosty wariant:
- Bridge ma dostęp do pliku `.smap` (export z Roboshop) i config JSON,
- Bridge tworzy katalog sceny i woła Core `/scenes/import`.

Future:
- Bridge może wystawiać HTTP endpointy zgodne z Roboshop, jeśli Roboshop potrafi push.

## 3. Wymagania dot. konwersji (MUST)
- Oryginalna mapa może mieć inne jednostki — Bridge/Map Compiler MUST skonwertować do metrów.
- Wszelkie identyfikatory LM/AP MUST zostać zachowane (spójne z robotem).
- Nieznane pola z Roboshop MUST być zachowane w `raw/meta` (dla debug), ale nie używane domenowo.

## 4. Proxy między Roboshop a robotem / RDS (kontekst)
Bridge nie zastępuje Proxy/Recorder.
Podsłuch protokołów to osobny tool (`15_proxy_recorder.md`).
