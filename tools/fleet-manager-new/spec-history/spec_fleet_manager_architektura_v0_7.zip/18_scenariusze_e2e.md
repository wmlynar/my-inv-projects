# Fleet Manager 2.0 — Scenariusze end-to-end (v0.7)

Scenariusze mają dwie funkcje:
- są „żywą specyfikacją” (jednoznaczna interpretacja),
- są testami E2E/regresji (możliwe do automatyzacji w CI).

---

## Scenariusz 0: Proxy/Recorder — uruchomienie, capture, archiwizacja (MVP-dev)

Cel: potwierdzić, że narzędzie reverse engineeringu działa „zawsze”, jest promptable i daje powtarzalny format logów.

Preconditions:
- `robokit-sim` działa lokalnie na `127.0.0.1` z portami RoboCore (np. 19204/19205/19206/19210/19301).
- `robot-controller` jest dostępny (dev/test).

Kroki:
1) Uruchom `robokit-sim`.
2) Uruchom proxy-recorder jako sesję i ustaw porty listen tak, by nie kolidowały z upstream.
   Przykład (listen w zakresie 292xx):
   - listen 29204 → upstream 19204
   - listen 29205 → upstream 19205
   - listen 29206 → upstream 19206
   - listen 29210 → upstream 19210
   - listen 29301 → upstream 19301
3) Uruchom `robot-controller` tak, aby łączył się do portów proxy (292xx), a nie bezpośrednio do sima.
4) Wykonaj sekwencję: `goTarget(LM2)` → poczekaj na status → `forkHeight(1.2)` → `stop`.
5) Zatrzymaj proxy-recorder.
6) Wykonaj `archive` i wygeneruj `manifest.json` z checksumami.

Oczekiwane (MUST):
- W katalogu sesji istnieje `session.meta.json5` z opisem sesji i listą listenerów.
- Dla każdego listenera są zapisane:
  - `connections.jsonl`,
  - `conn_*_raw_*.jsonl` (raw bytes w obie strony),
  - (jeśli decode) `conn_*_frames_*.jsonl`.
- Po archiwizacji istnieje `archive/<sessionName>.zip` oraz `manifest.json`.

---

## Scenariusz 0b: Robot-controller — smoke test protokołu (MVP-dev)

Cel: udowodnić, że potrafimy sterować robotem/symulatorem „jak Roboshop” i rozumiemy framing.

Preconditions:
- robokit-sim lub real robot jest dostępny,
- opcjonalnie proxy-recorder działa jako man-in-the-middle (zalecane w dev).

Kroki:
1) `robot-controller connect` do `TASK/CTRL/OTHER` (przez proxy lub direct).
2) Wyślij `goTarget(id="LM2")` (API 3051).
3) Odbierz status `robot_status_loc_req` (1004) lub push.
4) Wyślij `forkHeight(height=1.20)` (API 6040).
5) Potwierdź zmianę wysokości wideł w statusie.
6) Wyślij `stop` (2000).

Oczekiwane (MUST):
- robot-controller zapisuje log na dysk (komendy + ramki + timestamp),
- jeśli proxy działa: sesja zawiera raw bytes i dekodowane ramki zgodne z tym, co wysłał controller.

---

## Scenariusz 1: Start systemu bez UI (headless)
1) Uruchom Core, Gateway, Algo.
2) Import sceny (CLI lub API).
3) Activate scenę.
4) Core emituje `stateSnapshot`, `sceneActivated`.
5) Brak UI — system działa i publikuje SSE.

Oczekiwane:
- `/health` ok
- `/state` zawiera activeSceneId
- event log + snapshot na dysku

---

## Scenariusz 2: Dwa UI, jedno przejmuje kontrolę (seize control)
1) UI-A i UI-B łączą się do SSE.
2) UI-A robi `seize` (lease).
3) UI-B próbuje utworzyć task → 409 `CONTROL_LEASE_REQUIRED`.
4) UI-A robi `force seize` z UI-B (jeśli ustawione) → UI-B widzi wywłaszczenie.

---

## Scenariusz 3: goTarget (rolling target) na robokit-sim
1) Gateway przełącza RB-01 na `robokitSim`.
2) Core wysyła manual `goTarget(LM2)`.
3) Gateway wysyła TCP 3051 `{id:"LM2"}`.
4) Robot push/status pokazuje target i ruch.
5) Core widzi `arrived` → `commandCompleted`.

---

## Scenariusz 4: forkHeight jako ActionPoint
1) Scena ma `actionPoints.json5` dla `AP_PICK_01` (forkHeight 1.2m).
2) Task runner doprowadza robota do `AP_PICK_01` (goTarget).
3) Po arrival Core wysyła `forkHeight(height=1.2)` (6040).
4) Core czeka aż fork status osiągnie wysokość.
5) Eventy: `commandUpdated` + `taskUpdated`.

---

## Scenariusz 4b: Algorithm Level0 — PICK→DROP (walking skeleton, pojedynczy robot)

Cel: potwierdzić pionowy przekrój systemu w wariancie „najprościej jak się da”:
- algorytm wybiera task,
- Core wykonuje kroki,
- robot robi routing sam (Robokit),
- brak rezerwacji korytarzy i brak gwarancji braku kolizji (bo 1 robot).

Preconditions:
- `algorithm-service` działa w trybie `level0`.
- `fleet-core` działa w trybie `trafficMode=NONE`.
- W scenie aktywny jest dokładnie jeden robot `RB-01`.
- Scena ma zdefiniowane worksites `PICK_01` i `DROP_01` z `entryNodeId` oraz (preferowane) `actionNodeId`.

Kroki:
1) UI tworzy Task `PICK_01 → DROP_01` (albo importuje ze streamu).
2) Algorithm-service w `/algo/v1/decide` zwraca `taskUpdates`:
   - `status="assigned"` / `assignedRobotId="RB-01"`.
3) Core (TaskRunner) generuje lub weryfikuje plan kroków:
   - `moveTo(entryNodeId PICK_01)` → `goTarget`,
   - `moveTo(actionNodeId PICK_01)` → `goTarget` (jeśli istnieje),
   - `forkHeight(toHeightM=...)` (zgodnie z ActionPoint),
   - `moveTo(actionNodeId DROP_01)` → `goTarget`,
   - `forkHeight(toHeightM=...)` (drop),
   - (opcjonalnie) `moveTo(park)` jeśli brak kolejnych tasków.
4) Core wysyła do Gateway komendy domenowe (`CommandRecord`), a Gateway tłumaczy na:
   - `goTarget` (API 3051) z `LocationMark/ActionPoint`,
   - `forkHeight` (API 6040).
5) Core monitoruje arrival + status wideł i kończy task.

Oczekiwane (MUST):
- `locksRequested=[]` i brak blokad ruchu.
- Pełny audyt na dysk: event log + snapshoty stanu w tickach.
- W przypadku przerwy sieci: Core nie generuje command storm (patrz scenariusz 5).

---

## Scenariusz 5: Przerwa sieci do robota
1) Robot w trakcie jazdy.
2) Zrywamy TCP.
3) Gateway przechodzi w offline i raportuje.
4) Core holduje dispatch + emituje `systemWarning(DEPENDENCY_OFFLINE)`.
5) Po reconnect: kontynuacja.

---

## Scenariusz 6: Scene activation w trakcie ruchu
1) Robot jedzie.
2) UI robi activate nowej sceny.
3) Core wysyła best-effort stop, anuluje komendy i taski, resetuje locki.
4) Po aktywacji: stan czysty, UI widzi nową scenę.

---

## Scenariusz 7: Hot switch internalSim ↔ robocore (pojedynczy robot)
1) System startuje na internalSim.
2) W trakcie symulacji przełączamy RB-01 na robocore.
3) Core wykonuje safe-switch.
4) Robot kontynuuje wg nowych komend.

