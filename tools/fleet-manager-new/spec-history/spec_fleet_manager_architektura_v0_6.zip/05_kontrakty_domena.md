# Fleet Manager 2.0 — Kontrakty: domena (v0.6)

## 1. Roboty

### 1.1 RobotConfig (statyczne)
```json5
{
  robotId: "RB-01",
  displayName: "Forklift #1",

  footprint: {
    lengthM: 2.0,
    widthM: 0.9,
    safetyMarginM: 0.2,
  },

  limits: {
    maxVxMps: 1.2,
    maxAngularSpeedRadS: 1.0,
  },

  // preferowany provider
  defaultProvider: "robocore", // internalSim | robokitSim | robocore

  meta: { model: "X", notes: "..." },
}
```

### 1.2 RobotRuntimeState
```json5
{
  robotId: "RB-01",
  provider: {
    kind: "robocore",                 // internalSim | robokitSim | robocore
    status: "online",                 // offline | connecting | online | error
    statusReasonCode: "NONE",
    lastSeenTsMs: 1736160000123,
  },

  pose: { xM: 10.0, yM: 3.0, angleRad: 0.0 },
  velocity: { vxMps: 0.0, vyMps: 0.0, angularSpeedRadS: 0.0 },

  // uogólniony stan nawigacji (normalizowany z robota)
  navigation: {
    state: "idle", // idle | moving | paused | blocked | arrived | canceled | error
    stateReasonCode: "NONE",
    currentNodeId: "LM1",       // MAY (jeśli znane)
    targetNodeId: "AP_PICK_01", // MAY
    pathNodeIds: ["LM1", "LM2", "AP_PICK_01"], // MAY
  },

  // blokady i bezpieczeństwo
  blocked: {
    isBlocked: false,
    blockedReasonCode: "NONE",
    sinceTsMs: null,
  },

  // widełki (jeśli robot wspiera)
  fork: {
    heightM: 0.10,
    targetHeightM: 0.10,
    inPlace: true,
  },

  // bieżące wykonanie w Core
  currentCommandId: "cmd_01JH...",
  currentTaskId: "task_01JH...",
}
```

## 2. Worksites (pola odkładcze/odbiorcze)

### 2.1 Worksite (definicja)
```json5
{
  worksiteId: "PICK_01",
  worksiteType: "pickup", // pickup | dropoff | buffer | charger | park

  // Mapowanie na graf (LM/AP). Dla rolling target i planowania.
  entryNodeId: "LM10",        // MUST: LocationMark
  actionNodeId: "AP_PICK_01", // SHOULD: ActionPoint (dla akcji), może być null dla prostych miejsc

  // reguły
  constraints: {
    allowedRobotIds: ["RB-01", "RB-02"], // MAY
  },

  meta: { label: "Pick #01" },
}
```

### 2.2 WorksiteState (runtime)
```json5
{
  worksiteId: "PICK_01",
  occupancy: "occupied",  // unknown | empty | occupied | reserved
  occupancyReasonCode: "NONE",
  updatedTsMs: 1736160000123,
}
```

## 3. Streams

### 3.1 StreamDefinition
```json5
{
  streamId: "stream_inbound_01",
  enabled: true,

  // MVP: pickDrop loop
  kind: "pickDrop",

  params: {
    pickGroup: ["PICK_01", "PICK_02"],
    dropGroup: ["DROP_01", "DROP_02"],
    commitDistanceM: 8.0, // kiedy wybór drop staje się ostateczny (jeśli używane)
  },

  meta: { label: "Inbound" },
}
```

## 4. Tasks

### 4.1 Task (domena)
W MVP Task może być „wysokopoziomowy”, a plan (kroki) może być generowany przez Core.
Ale kontrakt przewiduje kroki, bo są potrzebne do akcji typu widły.

```json5
{
  taskId: "task_01JH...",
  createdTsMs: 1736160000000,

  streamId: "stream_inbound_01",
  kind: "pickDrop",

  fromWorksiteId: "PICK_01",
  toWorksiteId: "DROP_01",

  priority: 10,

  // runtime
  status: "created", // created | assigned | running | completed | failed | canceled
  statusReasonCode: "NONE",

  assignedRobotId: "RB-01", // null jeśli nieprzydzielone

  // opcjonalny plan kroków (Task Runner), czytelny dla człowieka i AI
  steps: [
    { stepId: "step_01", type: "moveTo", targetRef: { nodeId: "LM10" } },
    { stepId: "step_02", type: "moveTo", targetRef: { nodeId: "AP_PICK_01" } },
    { stepId: "step_03", type: "forkHeight", params: { toHeightM: 1.20 } },
    { stepId: "step_04", type: "moveTo", targetRef: { nodeId: "AP_DROP_01" } },
    { stepId: "step_05", type: "forkHeight", params: { toHeightM: 0.10 } },
  ],

  meta: { label: "PICK_01 -> DROP_01" },
}
```

### 4.2 TaskStep
```json5
{
  stepId: "step_03",
  type: "forkHeight", // moveTo | wait | forkHeight | io | custom
  targetRef: { nodeId: "AP_PICK_01" }, // dla moveTo; dla forkHeight MAY być null (jeśli akcja bez targetu)

  params: {
    // forkHeight
    fromHeightM: 0.10, // MAY
    toHeightM: 1.20,   // MUST
    toleranceM: 0.02,  // SHOULD
    timeoutMs: 20000,  // SHOULD
  },

  status: "pending", // pending | running | completed | failed | canceled
  statusReasonCode: "NONE",
}
```

**Zasada:** jeżeli `type = forkHeight`, a `targetRef` jest null, Core wykonuje akcję „tu i teraz”.
Jeżeli `targetRef` wskazuje ActionPoint, Core SHOULD najpierw doprowadzić robota do AP, a potem wykonać akcję.

## 5. CommandRecord (komendy do robota)
CommandRecord jest audytowalny i idempotentny end-to-end (Core→Gateway→Robot).

**Ważne (MUST):** statusy CommandRecord rozdzielają 3 różne rzeczy:
- Transport ACK (Core→Gateway) = `dispatched`,
- Robot protocol ACK (Gateway↔Robot) = `acknowledged` (jeśli wspierane),
- DONE = `completed` (decyduje Core na podstawie telemetrii/polityki).

Szczegóły semantyki: `07_semantyka_runtime_i_maszyny_stanow.md`.

```json5
{
  commandId: "cmd_01JH...",
  createdTsMs: 1736160000123,

  robotId: "RB-01",

  // typ komendy (MUST)
  type: "goTarget", // goTarget | goPoint | stop | pause | resume | cancel | forkHeight | forkStop | ...

  // payload domenowy (camelCase; gateway przetłumaczy na robot-protocol jeśli trzeba)
  payload: {
    // goTarget (rolling target): LM/AP
    targetRef: { nodeId: "LM2" },

    // opcjonalnie: rozwiązany identyfikator stacji/markera w protokole robota
    // (Core SHOULD wypełniać na podstawie SceneGraph.nodes[].externalRefs)
    targetExternalId: "LM2",

    // forkHeight
    toHeightM: 1.20,
  },

  // polityki per-komenda (SHOULD: jawnie, żeby nie było "magii")
  policy: {
    // ACK timeout: jeśli robot wspiera robot-ACK dla tej komendy
    ackTimeoutMs: 1200,   // SHOULD
    // EXEC timeout: ile maks. czekamy na DONE (np. arrival / fork reached)
    execTimeoutMs: 60000, // SHOULD
  },

  // lifecycle (patrz `07_*`)
  status: "created", // created | dispatched | acknowledged | completed | failed | canceled
  statusReasonCode: "NONE",

  // Transport ACK (Core→Gateway)
  transport: {
    status: "pending",   // pending | accepted | failed
    acceptedTsMs: null,  // wypełniane gdy Core dostanie HTTP 2xx z gateway
    httpStatus: null,    // np. 200/503 (debug)
    attempts: 0,         // ile razy Core próbował dispatch (bounded retry)
    lastErrorCauseCode: "NONE", // np. DEPENDENCY_OFFLINE | TIMEOUT
  },

  // Robot protocol ACK (Gateway↔Robot) — jeśli protokół wspiera
  robotAck: {
    status: "pending",   // pending | received | notSupported | failed
    receivedTsMs: null,
    apiNo: null,         // np. 3051
    seq: null,           // seq z nagłówka
    responseApiNo: null, // zazwyczaj apiNo+10000
    lastErrorCauseCode: "NONE",
  },

  // DONE (w domenie Core) — Core wyznacza completion na podstawie telemetrii/polityki
  completion: {
    status: "pending", // pending | completed | failed | canceled
    completedTsMs: null,
    detectedBy: "NONE", // NONE | navigationArrived | forkHeightReached | stopPolicy | manual
    details: { /* opcjonalnie: tolerancje, dystans, itp. */ },
  },

  request: { clientId: "ui-01", requestId: "req_01JH..." },
}
```

## 6. Locki i rezerwacje (podstawa dla multi-robot)
(MVP: można zacząć od prostego lockowania krawędzi/grup, ale kontrakt jest gotowy na rozszerzenia)

```json5
{
  lockId: "lock_01JH...",
  resourceType: "edgeGroup",   // edge | edgeGroup | node | area
  resourceId: "LM1<->LM2",     // klucz zasobu (kanoniczny)
  holderRobotId: "RB-01",
  status: "held",              // requested | held | released | expired
  statusReasonCode: "NONE",
  expiresTsMs: 1736160005123,
}
```
