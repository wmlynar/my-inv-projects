# Fleet Manager 2.0 — API Fleet Core (publiczne) (v0.6)

Base URL: `http://<core-host>:<port>/api/v1`

## 1. Zasady ogólne
- Wszystkie requesty/response są JSON (UTF-8).
- Błędy w `ErrorEnvelope` (patrz `03_*`).
- Endpointy modyfikujące stan **MUST** wymagać ważnego ControlLease (`leaseId`), inaczej `409`.
- Idempotencja: każdy endpoint mutujący stan MUST przyjmować `request: { clientId, requestId }`.
  - `(clientId, requestId)` jest kluczem idempotencji w skali endpointu.
  - Ten sam requestId ponowiony MUST zwrócić ten sam efekt (albo ten sam wynik), bez dubli.

## 2. Health
### GET /health
```json5
{ status: "ok", tsMs: 1736160000000 }
```

## 3. ControlLease (seize/release/renew)

### POST /control-lease/seize
Request:
```json5
{
  displayName: "UI Traffic Lab",
  ttlMs: 15000,
  force: false,
  request: { clientId: "ui-01", requestId: "req_01JH..." }
}
```
Response 200:
```json5
{ lease: { /* ControlLease */ } }
```

Errors:
- 409 `conflict` + `causeCode=CONFLICT` jeśli lease jest zajęty i `force=false`.

### POST /control-lease/release
Request:
```json5
{ leaseId: "lease_01JH...", request: { clientId: "ui-01", requestId: "req_01JH..." } }
```
Response 200: `{ ok: true }`

### POST /control-lease/renew
Request:
```json5
{ leaseId: "lease_01JH...", ttlMs: 15000, request: { clientId: "ui-01", requestId: "req_01JH..." } }
```
Response 200: `{ lease: { /* ControlLease */ } }`

## 4. Scenes

### GET /scenes
Response:
```json5
{ scenes: [{ sceneId: "scene_01...", sceneName: "warehouse_nowy_styl", createdTsMs: 1736160000000 }] }
```

### POST /scenes/import
- Body: zip (multipart) lub JSON wskazujący na lokalny katalog (MVP: wystarczy katalog w `sceneStoreDir`).
- Response:
```json5
{ sceneId: "scene_01...", ok: true }
```

### POST /scenes/activate
Request:
```json5
{ sceneId: "scene_01...", leaseId: "lease_01...", request: { clientId: "ui-01", requestId: "req_01..." } }
```
Response 200:
```json5
{ ok: true, activeSceneId: "scene_01..." }
```

## 5. State (snapshot)
### GET /state
Query params:
- `view=full|uiMinimal` (SHOULD)
- `include=robots,tasks,locks,worksites,streams` (MAY)

Response (skrót):
```json5
{
  cursor: 123456,
  tsMs: 1736160000123,
  activeSceneId: "scene_01...",
  robots: [ /* RobotRuntimeState[] */ ],
  tasks: [ /* Task[] */ ],
  locks: [ /* Lock[] */ ],
  worksites: [ /* Worksite + WorksiteState */ ],
  streams: [ /* StreamDefinition */ ],
}
```

## 6. Events (SSE)
### GET /events (SSE)
Query:
- `fromCursor=<int64>` (opcjonalne)
- `types=robotStateUpdated,taskUpdated,...` (opcjonalny filtr, SHOULD)
- `heartbeatMs=10000` (opcjonalne, MAY)

Reguły (MUST):
- SSE `id:` = `EventEnvelope.cursor`
- SSE `event:` = `EventEnvelope.type`
- SSE `data:` = JSON `EventEnvelope`
- Precedencja: jeśli jest `fromCursor`, ignoruj `Last-Event-ID`.
- Jeśli cursor poza retencją: wyślij `stateSnapshot` z `requiresResync=true`.

Przykład:
```text
id: 123456
event: robotStateUpdated
data: {"cursor":123456,"tsMs":1736160000123,"type":"robotStateUpdated","payload":{...}}

:heartbeat
```

## 7. Robots (read-only + provider switch przez Core)
### GET /robots
Response: `{ robots: [ /* RobotRuntimeState[] */ ] }`

## 8. Tasks
### POST /tasks
Tworzy nowe zadanie (np. pickDrop). Wymaga lease.
Request:
```json5
{
  leaseId: "lease_01...",
  task: {
    kind: "pickDrop",
    streamId: "stream_inbound_01",
    fromWorksiteId: "PICK_01",
    toWorksiteId: "DROP_01",
    priority: 10,
    // steps MAY być puste (Core wygeneruje), albo jawne
  },
  request: { clientId: "ui-01", requestId: "req_01..." }
}
```
Response:
```json5
{ taskId: "task_01...", ok: true }
```

### POST /tasks/{taskId}/cancel
Request:
```json5
{ leaseId: "lease_01...", request: { clientId: "ui-01", requestId: "req_01..." } }
```

## 9. Manual commands (opcjonalne, MVP: stop + goTarget)
### POST /robots/{robotId}/commands
Request (MVP):
```json5
{
  leaseId: "lease_01...",
  command: { type: "goTarget", payload: { targetRef: { nodeId: "LM2" } } },
  request: { clientId: "ui-01", requestId: "req_01..." }
}
```

## 10. Provider switch (z perspektywy UI)
### POST /robots/{robotId}/provider-switch
Request:
```json5
{
  leaseId: "lease_01...",
  targetProvider: "robokitSim", // internalSim | robokitSim | robocore
  request: { clientId: "ui-01", requestId: "req_01..." }
}
```

Core wykona procedurę safe-switch:
- emit `commandCreated(stop)` + dispatch best effort,
- wywoła gateway,
- emit `robotProviderSwitched`.

## 11. Out-of-scope (MVP)
- AuthN/AuthZ, TLS
- RBAC
- multi-tenant
- user management
