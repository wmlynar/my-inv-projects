# Fleet Manager 2.0 — Protokół RoboCore/Robokit (TCP framing) (v0.6)

Źródło prawdy w tej specyfikacji:
- reverse engineered + potwierdzone w kodzie `packages/adapters-robokit/src/rbk.js`
- robokit-sim (`apps/robokit-sim`) jako środowisko testowe
- docs `docs/rds/docs/ROBOKIT_API.md` (częściowo)

**Uwaga:** to jest protokół zewnętrzny. Fleet Manager **MUST NOT** go „ulepszać”.
Własne kontrakty (camelCase) obowiązują tylko na granicy Core↔Gateway.


## 0. Poziomy pewności (CONFIDENCE TAGS)

Ponieważ RoboCore/Robokit jest protokołem zewnętrznym i część rzeczy jest reverse engineered, w tym dokumencie
jawnie oznaczamy pewność informacji:

- **CONFIRMED** — potwierdzone na realnym robocie albo w oficjalnej dokumentacji (jeśli dostępna).
- **OBSERVED** — zaobserwowane w robokit-sim i/lub w capture z proxy (ale może zależeć od wersji).
- **HYPOTHESIS** — hipoteza robocza (implementacja MUSI być ostrożna i logować różnice).

W praktyce: parser MUST być odporny na warianty, a każde odchylenie SHOULD generować capture/warning.


## 1. Porty (OBSERVED)
(z kodu / symulatora; realny robot może mieć to samo)

- `STATE`: 19204 (status: 1000+, 1100)
- `CTRL`:  19205 (control: 2000+)
- `TASK`:  19206 (tasks: 3000+)
- `OTHER`: 19210 (other: 6000+)
- `PUSH`:  19301 (push stream: 9300 config, 19301 data)

## 2. Framing (MUST, CONFIRMED/OBSERVED)

### 2.1 Nagłówek (16 bajtów)
- 0: `startMark` = **0x5A** (1 byte)
- 1: `version` = **0x01** (1 byte)
- 2-3: `seq` (uint16 big-endian)
- 4-7: `bodyLength` (uint32 big-endian)
- 8-9: `apiNo` (uint16 big-endian)
- 10-15: `reserved` (6 bytes)

Payload:
- `bodyLength` bajtów UTF-8 JSON (czasem z binarnym ogonem; wtedy JSON length jest w reserved[2..3])

### 2.2 `reserved` i `jsonSize`
W praktyce część narzędzi ustawia w `reserved[2..3]` długość JSON (uint16 big-endian).
Parser Gateway MUST:
- jeśli `jsonSizeHeader > 0 && jsonSizeHeader <= bodyLength`, traktować pierwsze `jsonSizeHeader` bajtów jako JSON,
  a resztę jako binary (MAY ignorować jeśli nie używane),
- w innym wypadku próbować parsować cały body jako JSON.

### 2.3 Korelacja request/response
- Response ma `seq` taki sam jak request.
- Response `apiNo = requestApiNo + 10000`.
- Gateway MUST mapować to na `ack` dla Core.

## 3. Minimalny zestaw API (MVP) + mapowanie na Fleet Manager

### 3.1 Status (STATE port)
- `1004 robot_status_loc_req` — pozycja (x,y,angle) + current station + target + task status (w symulatorze)
- `1006 robot_status_block_req` — blokady
- `1020 robot_status_task_req` — stan nawigacji
- `1028 robot_status_fork_req` — stan wideł (jeśli dostępne)
- `1100 robot_status_all1_req` — paczka zbiorcza (opcjonalnie)

Gateway SHOULD używać push (PUSH port) jeśli dostępne; polling jako fallback.

### 3.2 Control (CTRL port)
- `2000 robot_control_stop_req` — awaryjny stop (bez payload)
- `2002 robot_control_reloc_req` — relokacja (payload zależny od robota)

### 3.3 Task (TASK port)
- `3001 robot_task_pause_req` — pause
- `3002 robot_task_resume_req` — resume
- `3003 robot_task_cancel_req` — cancel
- `3050 robot_task_gopoint_req` — go to point (x,y,angle) — MAY używane w sim/debug
- `3051 robot_task_gotarget_req` — go to target station (id = LM/AP) — **główna komenda rolling target**
- `3053 robot_task_target_path_req` — pobierz planowaną ścieżkę do targetu (opcjonalne)
- `3066 robot_task_multistation_req` — lista targetów (opcjonalne, future)
- `3068 robot_task_clear_task_req` — clear task (opcjonalne)

### 3.4 Other (OTHER port)
- `6040 robot_other_forkheight_req` — ustaw wysokość wideł `{height: <number>}`
- `6041 robot_other_forkstop_req` — zatrzymaj widły (bez payload)

### 3.5 Push (PUSH port)
- `9300 robot_push_config_req` — konfiguracja push (interval + include/exclude fields)
- `19301 robot_push` — push payload (status fields)

## 4. Ramki protokołu (payload) — kluczowe przypadki

### 4.1 goTarget (rolling target) — API 3051 (TASK port)
**To jest realizacja wymagania:** target jest LM/AP, nie (x,y).

Payload (observed w robokit-sim i wrapperze):
```json
{ "id": "LM2" }
```

- `id` to identyfikator stacji w mapie robota (LocationMark/ActionPoint).
- Gateway MUST zapewnić, że `id` odpowiada nodeId w `SceneGraph` i że scena/mapa jest spójna z mapą robota (operacyjnie).

**Mapping (Core→Gateway→Robot):**
- Core `CommandRecord.type = "goTarget"`
- Core SHOULD wypełniać `payload.targetExternalId` (z `Node.externalRefs`).
- Gateway wysyła `robot_task_gotarget_req` z `{id}` gdzie:
  - `id = payload.targetExternalId` jeśli podane,
  - w przeciwnym wypadku `id = payload.targetRef.nodeId`.

### 4.2 goPoint — API 3050 (TASK port)
Payload:
```json
{ "x": 10.0, "y": 3.0, "angle": 0.0 }
```
(angle opcjonalne)

### 4.3 forkHeight — API 6040 (OTHER port)
Payload (robokit-sim):
```json
{ "height": 1.20 }
```

**Jak mapujemy ActionPoint z parametrami „from→to” na RoboCore:**
- Core przy kroku `forkHeight`:
  1) Odczytuje bieżącą wysokość z `robot_status_fork_req` albo z push `fork.fork_height`.
  2) Jeśli `fromHeightM` jest podane: waliduje |current-from| <= tolerance (MAY; w MVP SHOULD logować warning, ale nie blokować).
  3) Wysyła `forkHeight(height=toHeightM)` (6040).
  4) Czeka aż status wideł potwierdzi osiągnięcie (w tolerancji) albo timeout.

### 4.4 forkStop — API 6041 (OTHER port)
Bez payload.

### 4.5 stop — API 2000 (CTRL port)
Bez payload.

### 4.6 push config — API 9300 (PUSH port)
Payload (z robokit-sim):
```json
{ "interval": 500, "include": ["x","y","angle","task_status","fork"] }
```
- `interval` w ms (min ograniczony przez robota/sim)
- `include` lub `exclude` (nie oba naraz)

## 5. Parser i odporność na błędy (MUST)
Gateway MUST:
- obsługiwać partial frames (dane przychodzą w kawałkach),
- resynchronizować się po błędnym `startMark` (szukać 0x5A),
- limitować `bodyLength` (ochrona przed OOM),
- wykrywać warianty `jsonSize` i logować błąd w capture,
- w razie parse error: zamknąć socket i wykonać reconnect z backoff.

## 6. Plan reverse engineering (SHOULD, ale bardzo zalecane)
- Proxy/Recorder zbiera raw frame hexdumps + decode (apiNo, seq, bodyLength, jsonSize).
- Golden traces: paczki z realnej komunikacji używane w testach integracyjnych Gateway.
- Minimalny zestaw testów:
  - decode/encode nagłówka,
  - goTarget + status,
  - forkHeight + status,
  - push config + push stream.

Szczegóły narzędzi: `15_proxy_recorder.md`, `16_obserwowalnosc_i_replay.md`.


## 7. Reverse engineering backlog (MUST przed „robot MVP”)

### 7.1 Obstacle avoidance / blokady / „robot chce omijać” (MUST)
W tej chwili mamy:
- API `1006 robot_status_block_req` (OBSERVED) — ale bez gwarancji pól i semantyki.
- reason codes w FM (`ROBOT_BLOCKED`, `ROBOT_WANTS_AVOIDANCE`) są domenowe i muszą być mapowane z prawdziwych danych.

MUST zebrać capture (proxy-recorder) dla przypadków:
- robot zablokowany przeszkodą na wąskim przejeździe,
- robot zablokowany innym robotem,
- robot wchodzi w tryb omijania (jeśli istnieje),
- robot prosi o interwencję operatora.

Wynik:
- uzupełnić ten dokument o:
  - dokładny payload statusu blokady,
  - listę pól oznaczających „avoidance requested/active”,
  - mapowanie na ReasonCode.

### 7.2 Sensory / lasery (FUTURE, ale dane zbieramy już teraz)
Długoterminowo chcemy ćwiczyć własny algorytm omijania przeszkód, więc warto zebrać dane sensorów.

SHOULD zebrać oddzielną sesję proxy:
- z ruchem danych z laserów (jeśli idzie po RoboCore/Robokit),
- z korelacją do pozycji robota (`1004`) i eventów task/command.

Na razie nie specyfikujemy pól (to zewnętrzne), ale MUST:
- logować raw bytes (zawsze),
- utrzymać sesje w katalogu z metadanymi i checksumami.

### 7.3 ACK vs DONE (MUST)
MUST potwierdzić na realnych capture:
- czy odpowiedź `apiNo+10000` zawsze przychodzi dla 3051/6040/2000,
- czy są komendy bez odpowiedzi,
- jakie pola w statusie oznaczają „arrived” i „fork reached”.

Wynik: doprecyzować pola i czasy w `05_*` i `07_*` (bez zmiany zewnętrznego protokołu).

