# Fleet Manager 2.0 — Konwencje i glosariusz (v0.6)

## 1. Słownik normatywny
W tym dokumencie słowa kluczowe są normatywne:

- **MUST** — wymaganie bezwzględne.
- **MUST NOT** — absolutny zakaz.
- **SHOULD** — zalecenie silne (odstępstwo wymaga uzasadnienia).
- **MAY** — opcjonalne.

## 2. Konwencje techniczne

### 2.1 Jednostki (MUST)
- Długości: **metry** (`m`).
- Prędkości liniowe: `m/s`.
- Kąty: **radiany** (`rad`).
- Prędkości kątowe: `rad/s`.
- Czas: **milisekundy** (`ms`) jako `int64` (timestamp epoch ms), chyba że wskazano inaczej.

### 2.2 Układy odniesienia (MUST)
- `mapFrame`: układ mapy/sceny (metry, 2D, prawoskrętny).
- `robotFrame`: układ robota (dla Robokit/RoboCore tam, gdzie API tego wymaga).
- W kontraktach domenowych Fleet Managera pozycje są w `mapFrame`, o ile nie zaznaczono inaczej.

### 2.3 Nazewnictwo i format danych (MUST)
- Wszystkie pola kontraktów i API Fleet Managera **MUST** używać **camelCase**.
- Nazwy pól **MUST** być po angielsku (np. `robotId`, `createdTsMs`, `forkHeightM`).
- Zewnętrzne protokoły (RoboCore/Robokit) **MUST NOT** być „poprawiane” — zachowujemy ich oryginalne nazwy pól (często `snake_case`).

### 2.4 Wersjonowanie (MUST)
- API: wersjonowanie w ścieżce: `/api/v1`, `/gateway/v1`, `/algo/v1`.
- Kontrakty: `contractsVersion` (string) w `SceneManifest` oraz `snapshot.schemaVersion`.
- Zmiany łamiące **MUST** zwiększać wersję główną API i/lub `contractsVersion`.

### 2.5 Identyfikatory i czas (MUST)
- `*Id` w domenie: **ULID** (string), np. `cmd_01JH1B...`.
- `cursor`: rosnąca liczba całkowita (`int64`) — monotoniczna w ramach instancji Core (MVP).
- `tsMs`: epoch ms.
- Wszystkie logi i snapshoty **MUST** zawierać `cursor` i `tsMs`.

### 2.6 Zasady walidacji requestów (anti-footgun)

#### 2.6.1 HTTP API (MUST)
- Serwer **MUST** odrzucać requesty z nieznanymi polami (`400 unknownField`),
  **z wyjątkiem** pól umieszczonych w obiektach `meta` lub `debug` (jeśli występują),
  gdzie nieznane pola **MUST** być ignorowane (bufor ewolucji kontraktów).

#### 2.6.2 Import sceny / zewnętrzne formaty (MUST)
- Parser zewnętrznych plików sceny (np. mapy) **MAY** tolerować nieznane pola, ale:
  - **MUST** zachować je w `raw.*` lub `meta.*` (dla debug/replay),
  - **MUST NOT** używać ich do logiki domenowej bez jawnego dodania do kontraktu.

### 2.7 JSON5 w dokumentacji (SHOULD)
- W przykładach używamy JSON5 (komentarze, trailing commas), bo jest czytelniejszy.
- Rzeczywiste API przesyła JSON (RFC 8259).

## 3. Glosariusz (pojęcia)

- **Scene** — aktywny zestaw: mapa + konfiguracja (worksites/streams/robots/…).
- **Scene Package** — paczka (katalog/zip) z plikami sceny, importowana do Core.
- **SceneGraph** — kanoniczny graf mapy (nodes/edges + geometria), wynik Map Compiler.
- **LocationMark (LM)** — punkt lokalizacji/pośredni, wykorzystywany jako target nawigacji.
- **ActionPoint (AP)** — punkt akcji (np. podniesienie wideł), też może być targetem nawigacji.
- **Rolling Target** — sterowanie wysokopoziomowe: Core/algorytm wysyła kolejne cele „do przodu” na trasie.
  W tej wersji specyfikacji Rolling Target jest wskazywany jako **NodeRef** (`LocationMark` lub `ActionPoint`),
  a nie współrzędne (x,y).
- **Worksite** — logiczne „miejsce pracy” (np. pole odkładcze/odbiorcze), mapowane na LM/AP.
- **Stream** — definicja procesu (np. inbound/outbound), generuje zadania.
- **Task** — zadanie domenowe (np. pickDrop).
- **CommandRecord** — zarejestrowana komenda do robota (idempotentna, audytowalna).
- **Provider** — implementacja sterowania robotem (np. `internalSim`, `robocore`, `robokitSim`).
- **Gateway** — usługa integracyjna, która rozmawia z robotami (TCP, itp.) i wystawia HTTP dla Core.
- **Lease / Seize control** — mechanizm wyłączności kontroli (jedna instancja UI może sterować, reszta read-only).
