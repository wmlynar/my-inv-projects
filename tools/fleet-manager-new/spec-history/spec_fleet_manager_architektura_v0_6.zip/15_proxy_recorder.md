# Fleet Manager 2.0 — Proxy/Recorder (dev tool) (v0.6)

Proxy/Recorder to **narzędzie developerskie** do podsłuchu i zapisu komunikacji:
- Roboshop ↔ robot,
- Roboshop ↔ RDS (gotowy fleet manager),
- Fleet Gateway ↔ robot (debug),
- robot-controller ↔ robot / robokit-sim (testy protokołu).

To jest element krytyczny dla reverse engineeringu RoboCore/Robokit oraz dla budowania **golden traces** do testów integracyjnych.

---

## 1. Cele i zasady (MUST)

### 1.1 Cele
Proxy/Recorder MUST umożliwiać:
- powtarzalne przechwytywanie pełnej komunikacji (TCP i HTTP) bez utraty bajtów,
- łatwe uruchomienie „na komendę” (promptable/AI-friendly),
- zapis sesji w formacie nadającym się do:
  - analizy człowieka (czytelne JSONL + metadane),
  - automatycznych testów (replay / golden),
  - archiwizacji incydentów (pakowanie z checksumami).

### 1.2 Zasady nadrzędne
- Proxy/Recorder MUST być **transparentnym** proxy: nie modyfikuje payloadów i nie zmienia kolejności bajtów.
- Proxy/Recorder MUST zapisywać **raw bytes w dwie strony** (client→server i server→client).
- Proxy/Recorder MUST działać niezależnie od Fleet Core/Gateway (osobny proces).
- Proxy/Recorder MUST działać na localhost i umożliwiać łatwe ustawienie upstreamów (robot/roboshop/rds).
- Proxy/Recorder MUST obsłużyć wiele listenerów i wiele połączeń równolegle.

### 1.3 Non-goals (MUST NOT)
- Proxy/Recorder MUST NOT próbować „naprawiać” ramek lub payloadów.
- Proxy/Recorder MUST NOT wprowadzać throttlingu w MVP (patrz §8).

---

## 2. Model uruchomieniowy: sesje (MUST)

### 2.1 Pojęcie sesji
„Sesja” to jedna, logicznie spójna rejestracja ruchu, np.:
- `gotarget_smoke_rb01`,
- `forkheight_pickdrop_test`,
- `roboshop_upload_map_warehouseA`,
- `avoidance_observed_2026-01-07`.

Proxy/Recorder MUST zapisywać każdą sesję w osobnym katalogu na dysku.

### 2.2 Domyślna lokalizacja logów (MUST)
Logi NIE mogą iść do repo (ryzyko rozmiaru). Domyślny katalog sesji MUST być poza repo:

- `~/robokit_logs/<YYYY-MM-DD>_<targetKind>_<sessionName>/`

Przykład:
- `~/robokit_logs/2026-01-07_robot_RB-01_gotarget_smoke/`

`targetKind` to jeden z:
- `robot`,
- `rds`,
- `charger`,
- `roboshop`,
- `mixed`.

Konfiguracja może to nadpisać, ale domyślnie MUST być poza repo.

---

## 3. Kontrakt CLI (MUST)

Proxy/Recorder MUST udostępniać CLI, które da się uruchomić bez czytania kodu źródłowego.

### 3.1 Komendy (MUST)
Proxy/Recorder MUST obsługiwać co najmniej:

- `proxy-recorder start ...` — start sesji i listenerów,
- `proxy-recorder stop --session <name|id>` — zatrzymanie sesji (graceful),
- `proxy-recorder list-sessions [--dir <rootDir>]` — lista sesji,
- `proxy-recorder status --session <name|id>` — status (aktywny/stopnięty, liczba conn, rozmiar),
- `proxy-recorder archive --session <name|id> [--delete-raw]` — spakuj sesję (patrz §9).

### 3.2 Minimalne parametry uruchomienia (MUST)
`start` MUST przyjmować:
- `--session <sessionName>` (MUST),
- `--description <text>` (SHOULD; trafia do metadanych sesji),
- `--root-dir <path>` (MAY; domyślnie `~/robokit_logs`),
- `--config <path.json5>` (MAY; jeżeli używany config, to CLI może nadpisywać),
- `--preset <name>` (MAY; patrz §7),
- `--print-effective-config` (SHOULD; bardzo pomocne dla AI i debug).

### 3.3 Przykłady uruchomienia (MUST: w specyfikacji)
#### A) „Postaw proxy na localhost, robot jest pod tym adresem”
```bash
proxy-recorder start \
  --session 2026-01-07_robot_RB-01_gotarget_smoke \
  --description "Smoke: goTarget + stop + forkHeight (roboshop-like)" \
  --preset robokit-all \
  --robot-id RB-01 \
  --upstream-host 10.0.0.11
```

#### B) „Podsłuchuj Roboshop↔Robot + Roboshop↔RDS na HTTP”
```bash
proxy-recorder start \
  --session 2026-01-07_mixed_roboshop_upload_map \
  --description "Upload mapy + konfiguracja sceny w Roboshop" \
  --config ./configs/proxy.roboshop_upload.json5
```

#### C) „Zakończ i zarchiwizuj”
```bash
proxy-recorder stop --session 2026-01-07_robot_RB-01_gotarget_smoke
proxy-recorder archive --session 2026-01-07_robot_RB-01_gotarget_smoke --delete-raw
```

### 3.4 Kody wyjścia i logi (MUST)
- `0` = sukces
- `1` = błąd walidacji config/CLI
- `2` = błąd bindowania portu (port zajęty)
- `3` = błąd upstream (nieosiągalny) — jeśli `--fail-fast=true`
- `>=10` = nieoczekiwany crash

CLI MUST logować:
- ścieżkę katalogu sesji,
- listę listenerów z mapowaniem listen→upstream,
- rozmiary plików (okresowo),
- ostrzeżenia o przekroczeniu limitów (patrz §8).

---

## 4. Kontrakt konfiguracji (JSON5) (MUST)

### 4.1 Minimalny plik config (MUST)
```json5
{
  session: {
    name: "2026-01-07_robot_RB-01_gotarget_smoke",
    description: "Smoke: goTarget + forkHeight + stop",
    operator: "jan.kowalski", // MAY
    targetKind: "robot",      // robot | roboshop | rds | charger | mixed
    rootDir: "~/robokit_logs",
  },

  // globalne limity (bez throttlingu w MVP)
  limits: {
    warnSessionSizeGb: 5,      // MUST emit warning
    rotateFileMb: 512,         // SHOULD (żeby pliki były przenośne)
    noThrottling: true,        // MUST w MVP
  },

  // listeners: każdy to jedno proxy listen→upstream
  listeners: [
    {
      name: "rb01_state",
      protocol: "tcp", // tcp | http
      listen: { host: "0.0.0.0", port: 19204 },
      upstream: { host: "10.0.0.11", port: 19204 },
      decode: { kind: "robocore" }, // robocore | none
    },
    {
      name: "rb01_ctrl",
      protocol: "tcp",
      listen: { host: "0.0.0.0", port: 19205 },
      upstream: { host: "10.0.0.11", port: 19205 },
      decode: { kind: "robocore" },
    },
    // ... task/other/push
  ],
}
```

### 4.2 Zasady (MUST)
- `listeners[].name` MUST być unikalne w sesji.
- `listen.port` MUST nie kolidować między listenerami.
- Dla `decode.kind="robocore"` proxy MUST próbować dekodować framing zgodnie z `10_protokol_robocore_robokit.md`,
  ale nawet przy decode error MUST zachować raw bytes.

---

## 5. Layout katalogu na dysku (MUST)

### 5.1 Struktura sesji
```text
<sessionDir>/
  session.meta.json5                # MUST: metadane sesji (opis, kto, co, gdzie)
  listeners.json5                   # MUST: effective config listenerów (po merge CLI+config)
  manifest.json                     # MUST: lista plików + checksums (po archiwizacji; patrz §9)
  tcp/
    <listenerName>/
      connections.jsonl             # lista połączeń (conn open/close)
      conn_<connId>_raw_000001.jsonl
      conn_<connId>_raw_000002.jsonl
      conn_<connId>_frames_000001.jsonl   # opcjonalnie, jeśli decode=robocore
      conn_<connId>.pcap                 # MAY (jeśli włączone)
  http/
    <listenerName>/
      requests_000001.jsonl         # request/response log (header + body) + raw bytes
      raw_000001.bin                # opcjonalne (pełne bajty w jednym pliku)
  archive/
    <sessionName>.zip               # wynik `archive` (SHOULD)
```

### 5.2 Metadane sesji (MUST)
`session.meta.json5` MUST zawierać co najmniej:
```json5
{
  sessionName: "2026-01-07_robot_RB-01_gotarget_smoke",
  description: "Smoke: goTarget + forkHeight + stop",
  startedTsMs: 1736210000000,
  endedTsMs: null, // wypełniane po stop
  operator: "jan.kowalski", // MAY
  targets: [
    { kind: "robot", robotId: "RB-01", addr: "10.0.0.11" },
  ],
  listeners: [
    { name: "rb01_task", protocol: "tcp", listen: "0.0.0.0:19206", upstream: "10.0.0.11:19206", decode: "robocore" },
  ],
  notes: [
    "W tej sesji wykonano: goTarget(LM2), forkHeight(1.20), stop",
  ],
}
```

To jest element celowo „AI-friendly”: można indeksować sesje po opisie, budować z nich golden tests.

---

## 6. Format capture (MUST)

### 6.1 Zdarzenia połączeń (MUST)
`tcp/<listener>/connections.jsonl` — jeden wpis na open/close, np.:
```json5
{ tsMs: 1736210000001, event: "connOpened", connId: "c01", local: "0.0.0.0:19206", peer: "10.0.0.50:53421", upstream: "10.0.0.11:19206" }
{ tsMs: 1736210012345, event: "connClosed", connId: "c01", reason: "eof" }
```

### 6.2 Raw stream (MUST)
`conn_<connId>_raw_*.jsonl` MUST zawierać **wszystkie bajty** w obie strony.
Każdy wpis reprezentuje chunk (niekoniecznie pełną ramkę):

```json5
{
  tsMs: 1736210000123,
  connId: "c01",
  dir: "c2s",            // c2s | s2c
  nBytes: 128,
  bytesBase64: "AAECAwQF...", // MUST: raw bytes (base64)
  // pomocniczo:
  bytesHexPreview: "5a0100ff....", // SHOULD: max np. 64B
}
```

Zasady:
- Proxy MUST zachować kolejność wpisów per (connId, dir).
- Proxy MUST NOT scalać lub przerabiać bajtów.
- Proxy SHOULD rotować pliki po `limits.rotateFileMb`.

### 6.3 Decode RoboCore frames (SHOULD, ale bardzo przydatne)
Jeśli `decode.kind="robocore"`, proxy SHOULD generować równoległy plik:
`conn_<connId>_frames_*.jsonl`, gdzie każdy wpis to zdekodowana ramka (o ile możliwe):

```json5
{
  tsMs: 1736210000456,
  connId: "c01",
  dir: "c2s",
  decode: {
    kind: "robocore",
    confidence: "OBSERVED", // CONFIRMED | OBSERVED | HYPOTHESIS
  },
  header: {
    startMarkHex: "5a",
    version: 1,
    seq: 42,
    apiNo: 3051,
    bodyLength: 12,
    jsonSizeHeader: 12,
  },
  json: { id: "LM2" },      // jeśli parsowalne
  binaryTailBase64: null,   // jeśli występuje
  rawFrameBase64: "WgE...", // SHOULD: pełna ramka (łatwe do replay)
  parseError: null,
}
```

Jeżeli dekoder nie potrafi:
- wpis MUST zawierać `parseError` i `rawFrameBase64`, a `json` = null.

### 6.4 HTTP capture (MUST)
Dla `protocol="http"` proxy MUST logować:
- request line + headers,
- response status + headers,
- body (raw bytes) w obie strony.

Przykład wpisu:
```json5
{
  tsMs: 1736211000123,
  connId: "h07",
  method: "POST",
  url: "http://roboshop.local/api/maps/upload",
  requestHeaders: { "content-type": "application/json" },
  requestBodyBase64: "eyJ..." ,
  responseStatus: 200,
  responseHeaders: { "content-type": "application/json" },
  responseBodyBase64: "eyJvayI6dHJ1ZX0=",
}
```

---

## 7. Presety i „capture wszystkiego” (SHOULD)

Proxy/Recorder SHOULD dostarczyć presety, bo w praktyce chcesz jednym poleceniem przechwycić wszystkie porty RoboCore.

### 7.1 Preset `robokit-all` (SHOULD)
MUST uruchomić listenery TCP dla portów (domyślne, observed):
- 19204 STATE
- 19205 CTRL
- 19206 TASK
- 19210 OTHER
- 19301 PUSH

Z możliwością nadpisania portów w config (nie każdy robot ma identyczne).

### 7.2 Preset `http-all` (SHOULD)
- Startuje listenery HTTP dla listy portów podanej przez użytkownika (np. `--http-ports 80,8080,3000`).
- W MVP zakładamy listę jawnie podaną (wildcard na „wszystkie porty systemu” nie jest realistyczny na każdym OS).

---

## 8. Duże logi: rotacja, ostrzeżenia, brak throttlingu (MUST)

- Proxy/Recorder MUST logować **bez throttlingu** w MVP.
- Proxy/Recorder MUST emitować ostrzeżenie, gdy rozmiar sesji przekroczy `limits.warnSessionSizeGb`.
- Proxy/Recorder SHOULD rotować pliki (np. co 512MB), żeby uniknąć:
  - problemów z kopiowaniem,
  - problemów z edytorami,
  - pojedynczych ogromnych plików.

Przykładowy warning:
- `WARNING: session size exceeded 5GB (current: 5.4GB). Consider archiving or enabling throttling (post-MVP).`

Throttling MAY pojawić się post-MVP, ale MUST być jawny i domyślnie wyłączony.

---

## 9. Archiwizacja i manifest (SHOULD, ale manifest MUST jeśli archiwizujemy)

### 9.1 Archiwizacja
`proxy-recorder archive --session ...` SHOULD:
- spakować katalog sesji do `archive/<sessionName>.zip` (lub tar.zst),
- wygenerować `manifest.json` z listą plików i checksumami,
- (opcjonalnie) przenieść surowe pliki do archiwum i usunąć je (`--delete-raw`).

### 9.2 Manifest (MUST, jeśli tworzymy archiwum)
```json
{
  "sessionName": "2026-01-07_robot_RB-01_gotarget_smoke",
  "createdTsMs": 1736210500000,
  "files": [
    { "path": "session.meta.json5", "sha256": "..." },
    { "path": "tcp/rb01_task/conn_c01_raw_000001.jsonl", "sha256": "..." }
  ]
}
```

---

## 10. Integracja z testami i replay (SHOULD)

- `fleet-gateway` SHOULD mieć testy integracyjne, które biorą jako wejście:
  - `conn_*_frames_*.jsonl` (jeśli dostępne) albo `raw` + dekoder w testach,
  - i sprawdzają, że parser/encoder jest zgodny z capture.
- `robot-controller` SHOULD umieć:
  - odtwarzać „goTarget / forkHeight / stop” na podstawie capture,
  - generować nową sesję proxy dla regresji.

Szczegóły: `16_obserwowalnosc_i_replay.md`, `17_strategia_testow.md`.

---

## 11. Failure modes (MUST)

- Jeśli upstream nieosiągalny:
  - w trybie `--fail-fast=true` proxy MUST zakończyć proces z kodem 3,
  - w przeciwnym razie proxy MAY działać i logować błędy połączeń.
- Jeśli decode RoboCore się nie uda:
  - proxy MUST nadal logować raw bytes,
  - MUST logować `parseError` w frames jsonl.
- Jeśli port zajęty:
  - proxy MUST zakończyć się kodem 2 i wypisać konflikt portu.

