# Fleet Manager 2.0 — MVP (dokładna definicja + plan implementacji) (v0.6)

MVP ma być podstawą do:
- implementacji pierwszej wersji algorytmu,
- uruchomienia na `internalSim`,
- uruchomienia na `robokit-sim`,
- oraz bezpiecznego wejścia na realnego robota (etapowo, po potwierdzeniu protokołu).

**Kluczowa zmiana praktyczna:** zanim wejdziemy w Core/Gateway „na serio”, MUST mieć działające narzędzia
do podsłuchu i replay protokołu (`proxy-recorder`, `robot-controller`), bo to minimalizuje ryzyko integracyjne.

---

## 1. MUST w MVP (produktowe minimum)

### 1.1 Fleet Core (source of truth)
Core MUST dostarczyć:
- Import sceny (katalog lub zip) + walidacja.
- Activate sceny (procedura atomowa) + jawna semantyka „co się dzieje przy przełączeniu”.
- `GET /state` snapshot + `GET /events` SSE (EventEnvelope).
- ControlLease (seize/renew/release + seize control wywłaszcza poprzedniego).
- Event log + snapshoty **na dysk** (wymóg bezdyskusyjny).
- Manual commands (MVP): `stop`, `goTarget`.
- Minimalny Task Runner: `pickDrop` + kroki `moveTo` i `forkHeight`.
- Integracja z Algorithm Service (HTTP): `POST /algo/v1/decide` (w MVP algo może być stubem, ale port i kontrakt muszą istnieć).

### 1.2 Fleet Gateway (adapter do robotów)
Gateway MUST dostarczyć:
- Provider: `internalSim` + `robokitSim` + `robocore` (ten sam protokół TCP).
- Obsługa framingu RoboCore/Robokit (robust parser + resync + partial frames).
- Minimalne komendy TCP:
  - 3051 `goTarget` (rolling target: LM/AP),
  - 2000 `stop`,
  - 6040 `forkHeight`,
  - 6041 `forkStop`.
- Minimalny status:
  - 1004 `robot_status_loc_req` (pozycja),
  - (opcjonalnie) push 9300/19301.
- Idempotencja dla `commandId` + limity inflight + cooldown po reconnect (anti command-storm).
- Hot-switch providera per robot.

### 1.3 Algorithm Service (port decyzyjny)
Algorithm Service MUST dostarczyć:
- `/health`
- `/algo/v1/decide`
- deterministyczny stub (np. zawsze hold) albo minimalną logikę,
- testy deterministyczności na golden input/output.

### 1.4 UI (operator)
UI MUST dostarczyć:
- read-only dashboard: mapa + roboty + tasks + worksites + streams,
- kontrola: seize/release + manual stop + manual goTarget,
- natychmiastowy read-only po utracie lease,
- odporność na reconnect SSE (odtwarzanie od cursor).

### 1.5 Map Compiler
Map Compiler MUST dostarczyć:
- `.smap` → `graph.json` (nodes, edges, `DegenerateBezier`, `propsCompiled.lengthM`),
- deterministyczność + walidacje,
- golden testy (wejście `.smap` → oczekiwane `graph.json`).

---

## 2. MUST w MVP-dev (narzędzia, które odblokowują integrację)

Te elementy nie są „featurem dla operatora”, ale są krytyczne, żeby w ogóle bezpiecznie wejść w robota.

### 2.1 Proxy/Recorder (proxy-recorder)
Proxy/Recorder MUST:
- uruchamiać się z CLI + config (promptable),
- logować raw bytes w dwie strony,
- mieć layout logów poza repo,
- ostrzegać o dużych logach,
- umożliwiać archiwizację + manifest z checksumami.

Spec: `15_proxy_recorder.md`.

### 2.2 Robot controller (robot-controller)
robot-controller MUST:
- potrafić wykonać smoke test protokołu (goTarget/stop/forkHeight),
- potrafić działać przeciwko robokit-sim i przeciwko real robot (w bezpiecznych warunkach),
- logować na dysk sekwencje komend i statusów,
- umieć replay z capture (co najmniej w trybie offline test harness).

---

## 3. SHOULD w MVP (silnie zalecane)
- SSE filter `types=`.
- `/state?view=uiMinimal`.
- Gateway capture w debug.
- Golden trace pipeline (z proxy/gateway/core).

---

## 4. Poza MVP (explicit)
- Security (authN/authZ/TLS/RBAC)
- Multi-instance Core / HA
- Automatyczne ładowanie mapy do robota (Roboshop sync)
- Zaawansowane obstacle avoidance (lokalne planowanie + „width>0”)
- Rozbudowane UI (edycja sceny w UI)

---

## 5. Plan implementacji MVP (komponentami, w kolejności minimalizującej ryzyko)

Ta kolejność jest celowa: najszybciej budujemy pętlę feedbacku i redukujemy ryzyko integracyjne.

### Faza 0 — Golden assets i katalogowanie sesji (MUST)
- Skatalogować istniejące logi/sesje (z proxy) jako „golden set”:
  - nazwy sesji,
  - do czego służą,
  - checksumy,
  - minimalny README per sesja.

### Faza 1 — Proxy/Recorder (pierwsze!)
Deliverables:
- CLI + config + presety robokit-all,
- layout logów w `~/robokit_logs/...`,
- raw bytes w obie strony,
- warning o rozmiarze,
- archiwizacja + manifest.

Testy:
- unit (writer/rotacja/manifest),
- integration (proxy up → połączenie → zapis → archive → checksum).

### Faza 2 — Robot-controller (smoke test protokołu)
Deliverables:
- connect + goTarget(LM/AP) + stop + forkHeight,
- logowanie na dysk (komendy + statusy),
- replay sekwencji z capture.

Testy:
- przeciwko robokit-sim,
- opcjonalnie przeciwko real robot (kontrolowane warunki).

### Faza 3 — Robokit-sim (albo dopięcie istniejącego)
Deliverables:
- minimalne API: status + goTarget + forkHeight + stop + push (zgodnie z `10_*`),
- tryb „scripted replay” (odtwarzanie statusów z logów) — bardzo pomocne,
- (opcjonalnie) prosta fizyka.

### Faza 4 — Fleet-gateway (HTTP + TCP)
Deliverables:
- `/gateway/v1` komendy z idempotencją,
- provider switching,
- reconnect/retry/circuit breaker,
- capture debug na dysk.

Testy:
- golden TCP traces,
- chaos tests (dropy, partial frames).

### Faza 5 — Fleet-core (event sourcing + API)
Deliverables:
- event log + snapshoty na dysk,
- import + activate sceny,
- `/state` + SSE,
- ControlLease,
- manual commands,
- minimal Task Runner + integracja z algo stub.

Testy:
- deterministyczny replay,
- scenariusze E2E.

### Faza 6 — Algorithm-service (stub → real)
Deliverables:
- `/algo/v1/decide` z kontraktami,
- deterministyczne testy, golden I/O.

### Faza 7 — UI-frontend
Deliverables:
- read-only + lease + manual,
- debug widoki (reason codes, current command, rolling target).

---

## 6. Kryteria akceptacji MVP (MUST)
- Wszystkie scenariusze z `18_scenariusze_e2e.md` przechodzą na robokit-sim.
- Event log + snapshot pozwalają odtworzyć stan po awarii.
- Przerwy w komunikacji nie powodują „pętli komend” (command storm) i nie gubią audytu.
- Proxy/Recorder potrafi w powtarzalny sposób zebrać sesję i ją zarchiwizować.

---

## 7. Blokujące niejednoznaczności (MUST rozstrzygnąć przez capture / RE)

1) **RoboCore/Robokit: reason codes blokad i obstacle avoidance** (kiedy i jak robot zgłasza, że chce omijać).  
2) **ACK vs DONE**: doprecyzować, które ramki są ack (seq/apiNo) oraz które statusy oznaczają zakończenie.  
3) **Sensory (laser) — capture**: zebrać i skatalogować sesję z danymi sensorów (post-MVP algorytm), ale dane zbieramy już teraz.  
4) **Porty i warianty protokołu**: potwierdzić na real robocie (proxy + robot-controller).

Szczegóły RE i checklista: `10_protokol_robocore_robokit.md`.

